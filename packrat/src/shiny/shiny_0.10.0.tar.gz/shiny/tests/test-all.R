library(testthat)
library(shiny)

test_package("shiny")

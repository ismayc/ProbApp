library(testthat)
library(mosaic)
test_package("mosaic")

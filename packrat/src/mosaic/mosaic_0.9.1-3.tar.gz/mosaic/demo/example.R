# this is just a placeholder
data(iris)
rdata(10,iris$Species)
ddata('setosa',iris$Species)
pdata(3:6, iris$Sepal.Length)
qdata(.5, iris$Sepal.Length)

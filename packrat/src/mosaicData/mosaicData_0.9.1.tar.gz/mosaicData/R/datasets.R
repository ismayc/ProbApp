#' Volume of Users of a Rail Trail
#'
#' The Pioneer Valley Planning Commission (PVPC) collected data north of Chestnut Street in 
#' Florence, MA for ninety days from April 5, 2005 to November 15, 2005. Data collectors set up a 
#' laser sensor, with breaks in the laser beam recording when a rail-trail user passed the 
#' data collection station.  
#'
#' @docType data
#' @name RailTrail
#' @usage data(RailTrail)
#' @format
#'   A data frame with 90 observations on the following variables.
#'   \itemize{
#'     \item{\code{hightemp}} {daily high temperature (in degrees Fahrenheit)}
#'     \item{\code{lowtemp}} {daily low temperature (in degrees Fahrenheit)}
#'     \item{\code{avgtemp}} {average of daily low and daily high temperature (in degrees Fahrenheit)}
#'     \item{\code{spring}} {indicator of whether the season was Spring}
#'     \item{\code{summer}} {indicator of whether the season was Summer}
#'     \item{\code{fall}} {indicator of whether the season was Fall}
#'     \item{\code{cloudcover}} {measure of cloud cover (in oktas)}
#'     \item{\code{precip}} {measure of precipitation (in inches)}
#'     \item{\code{volume}} {estimated number of trail users that day (number of breaks recorded)}
#'     \item{\code{weekday}} {indicator of whether the day was a non-holiday weekday}
#'   }
#'
#' @details
#' There is a potential for error when two users trigger the infrared beam at exactly the same time since the counter 
#' would only logs one of the crossings.  The collectors left the motion detector out during the winter, but because the 
#' counter drops data when the temperature falls below 14 degrees Fahrenheit, there is no data for the cold winter months. 
#'
#' @source
#' Pioneer Valley Planning Commission
#'
#' @references
#' http://www.fvgreenway.org/pdfs/Northampton-Bikepath-Volume-Counts%20_05_LTA.pdf
#'
#' @examples
#' data(RailTrail)
#'

NA

#' Alcohol Consumption per Capita
#'
#' These data provide per capita alcohol consumption values
#' for many countries in 2005 and 2008.  There are also a few
#' countries for which there are data in other years.
#'
#' @docType data
#' @name Alcohol
#' @usage data(Alcohol)
#' @format
#'   A data frame with 411 observations on the following variables.
#'   \itemize{
#'     \item{\code{country}} {country name}
#'     \item{\code{year}} {year}
#'     \item{\code{alcohol}} {per capita alcohol consumption}
#'   }
#'
#' @source
#' Gapminder (http://www.gapminder.org/)
#'
#' @references
#' http://www.fvgreenway.org/pdfs/Northampton-Bikepath-Volume-Counts%20_05_LTA.pdf
#'
#' @examples
#' data(Alcohol)
#' # There are only a few observations in years other than 2005 and 2008
#' subset(Alcohol, ! year %in% c(2005,2008))

NA
#' US Births in 1969 - 1988
#'
#' A day by day record of the number of births in each US State.
#' 
#' @docType data
#' @name Birthdays
#' @usage data(Birthdays)
#' @format 
#'   A data frame with 374221 observations on the following variables.
#'   \itemize{
#'     \item{\code{state}} {state where child was born}
#'     \item{\code{year}} {year (1969-1988)}
#'     \item{\code{month}} {month (1-12)}
#'     \item{\code{day}} {day of month}
#'     \item{\code{date}} {date as a date object}
#'     \item{\code{births}} {number of births}
#'   }
#' 
#' @examples
#' data(Birthdays)
#' if (require(lattice)) {
#'   xyplot(births ~ date, Birthdays, subset=state=="CA")
#'   xyplot(births ~ date, Birthdays, subset=state=="CA", 
#'     groups=wday, type='l')
#'   if (require(mosaic)) {
#'     xyplot(births ~ date, type='l',
#'       data = Birthdays %>% group_by(date) %>% summarise(births=sum(births)))
#'     }
#'   }

NA 

#' US Births in 1978
#'
#' A day by day record of the number of births in the United States in 1978.
#' 
#' @docType data
#' @name Births78
#' @usage data(Births78)
#' @format 
#'   A data frame with 365 observations on the following variables.
#'   \itemize{
#'     \item{\code{date}} {date in 1978}
#'     \item{\code{births}} {number of US births}
#'     \item{\code{dayofyear}} {sequential number of days from 1 to 365}
#'   }
#' 
#' @examples
#' data(Births78)
#' if (require(lattice)) {
#'   xyplot(births ~ date, Births78)
#'   xyplot(births ~ date, Births78, groups=dayofyear%%7)
#' }

NA 

#' Standard Deck of Cards
#' 
#' A character vector with two or three character representations of 
#' each card in a standard 52-card deck.
#' 
#' @name Cards
#' @aliases card
#' @docType data
#' 
#' @usage Cards
#' 
#' @details
#' The 2 of clubs is represented as "2C", while the 10 of diamonds is "10D".
#' 
#' @examples
#' if (require(mosaic)) {
#'   deal(Cards, 13)        # bridge hand
#'   deal(Cards, 5)         # poker hand
#'   shuffle(Cards)         # shuffled deck
#' }
#' 
#' @keywords datasets

NA 

#' Countries
#' 
#' A data frame containing country names as used by GapMinder and the \code{maps}
#' package to facilitate converstion between the two.
#' 
#' @name Countries
#' @aliases Countries
#' @docType data
#' 
#' @usage data(Countries)
#' @format 
#'   A data frame with 258 observations on the following variables.
#'   \itemize{
#'     \item{\code{worldmap}} {region name http://mappinghacks.com/ data sets}
#'     \item{\code{gapminder}} {country name in GapMinder data sets}
#'     \item{\code{maps}} {region name in \code{maps} data sets}
#'   }
#' 
#' @details
#' The "countries" in the \code{maps} data include several other geographic regions (bodies
#' of water, islands belonging to other countries, Hawaii, etc.) that are not countries.
#' Furthermore, the \code{maps} countries do not include many of the countries that
#' have been created since ca. 2000.  The mapping is therefore many-to-many, and also
#' includes some NAs when there is no appropriate mapping.  Bodies of water in the
#' \code{maps} data, for example, are not assigned a country in the GapMinder.
#' 
#' @examples
#' data(Countries)
#' subset(Countries, maps=="Yugoslavia")  # Where has Yugoslavia gone?
#' subset(Countries, is.na(gapminder))    # Things from maps with no GapMinder equivalent
#' subset(Countries, is.na(maps))         # Things from GapMinder with no maps equivalent

#' @keywords datasets

NA 


#' Data from the 1985 Current Population Survey (CPS85)
#' 
#' The Current Population Survey (CPS) is used to supplement census
#' information between census years. These data consist of a random
#' sample of persons from the CPS85, with information on wages and
#' other characteristics of the workers, including sex, number of years
#' of education, years of work experience, occupational status, region of
#' residence and union membership.  
#' 
#' @docType data
#' @name CPS85
#' @usage data(CPS85)
#' @format 
#'   A data frame with 534 observations on the following variables.
#'   \itemize{
#'     \item{\code{wage}} {wage (US dollars per hour)}
#'     \item{\code{educ}} {number of years of education}
#'     \item{\code{race}} {a factor with levels \code{NW} (nonwhite) or \code{W} (white)}
#'     \item{\code{sex}} {a factor with levels \code{F} \code{M}}
#'     \item{\code{hispanic}} {a factor with levels \code{Hisp} \code{NH}}
#'     \item{\code{south}} {a factor with levels \code{NS} \code{S}}
#'     \item{\code{married}} {a factor with levels \code{Married} \code{Single}}
#'     \item{\code{exper}} {number of years of work experience (inferred from \code{age} and
#' \code{educ})}
#'     \item{\code{union}} {a factor with levels \code{Not} \code{Union}}
#'     \item{\code{age}} {age in years}
#'     \item{\code{sector}} {a factor with levels \code{clerical} \code{const}
#' \code{manag} \code{manuf} \code{other} \code{prof} \code{sales} \code{service}} 
#'   }
#' 
#' @details
#' Data are from 1985.
#' The data file is recoded from the original, which had
#' entirely numerical codes.  
#' 
#' @source
#' Data are from \url{http://lib.stat.cmu.edu/datasets/CPS_85_Wages}.
#' 
#' @references
#' Berndt, ER. \emph{The Practice of Econometrics} 1991. Addison-Wesley. 
#' 
#' @examples
#' data(CPS85)
#' 

NA

#' Galton's dataset of parent and child heights
#' 
#' In the 1880's, Francis Galton was developing ways to quantify the
#' heritability of traits.  As part of this work, he collected data on
#' the heights of adult children and their parents.  
#' 
#' @docType data
#' @keywords datasets
#' @name Galton
#' @usage data(Galton)
#' @format 
#'   A data frame with 898 observations on the following variables.
#'   \itemize{
#'     \item{\code{family}} {a factor with levels for each family}
#'     \item{\code{father}} {the father's height (in inches)}
#'     \item{\code{mother}} {the mother's height (in inches)}
#'     \item{\code{sex}} {the child's sex: \code{F} or \code{M}}
#'     \item{\code{height}} {the child's height as an adult (in inches)}
#'     \item{\code{nkids}} {the number of adult children in the family, or, at least,
#' the number whose heights Galton recorded.}
#'   }
#' 
#' @details 
#' Entries were deleted for
#' those children whose heights were not recorded numerically by Galton,
#' who sometimes used entries such as ``tall'', ``short'', ``idiotic'',
#' ``deformed'' and so on.
#' 
#' @source 
#' The data were transcribed by J.A. Hanley who has published them at
#' \url{http://www.medicine.mcgill.ca/epidemiology/hanley/galton/}
#' 
#' @references 
#' "Transmuting" women into men: Galton's family data on human stature. (2004)
#' \emph{The American Statistician}, 58(3):237-243.
#' 
#' @examples 
#' data(Galton)
#' 
#' @keywords datasets
#' 
#' 

NA
#' Data from a heat exchanger laboratory
#'
#' These data were collected by engineering students at Calvin College.
#' The apparatus consists of concentric pipes insulated from the environment so that
#' as nearly as can be managed the only heat exchange is between the hot and cold water.
#'
#' @docType data
#' @keywords datasets
#' @name HeatX
#' @usage data(HeatX)
#' @format 
#'   A data frame with 6 observations on the following variables.
#'   \itemize{
#'     \item{\code{trial}} {trial number}
#'     \item{\code{T.cold.in}} {temperature (C) of the cold water as it enters the apparatus}
#'     \item{\code{T.cold.out}} {temperature (C) of the cold water as it leaves the apparatus}
#'     \item{\code{m.cold}} {flow rate (L/min) of the cold water}
#'     \item{\code{T.hot.in}} {temperature (C) of the hot water as it enters the apparatus}
#'     \item{\code{T.hot.out}} {temperature (C) of the hot water as it leaves the apparatus}
#'     \item{\code{m.hot}} {flow rate (L/min) of the hot water}
#'   }
#' @examples
#' # We can test for heat exchange with the environment by check to see if the 
#' # heat gained by the cold water matches the heat lost by the hot water.
#' C_p <- 4.182 / 60  # / 60 because measureing m in L/min
#' HeatX2 <- transform(HeatX, 
#'                 Q.cold = m.cold * C_p * (T.cold.out - T.cold.in),
#'                 Q.hot= m.hot * C_p * (T.hot.out- T.hot.in)
#')
#' HeatX2 <- transform(HeatX2, Q.env = Q.cold + Q.hot)
#' if (require(mosaic)) {
#'   stripplot( ~ Q.env, data=HeatX2, alpha=.6, cex=2, jitter.data=TRUE, factor=4)
#'   t.test( ~Q.env, data = HeatX2 )
#' }

NA

#' Data from the Child Health and Development Studies
#' 
#' Birth weight, date, and gestational period collected as part of the Child
#' Health and Development Studies in 1961 and 1962.  Information about the baby's
#' parents --- age, education, height, weight, and whether the mother smoked is
#' also recorded.  
#' 
#' @name Gestation
#' @usage data(Gestation)
#' @docType data
#' 
#' @format 
#'   A data frame with 1236 observations on the following variables.
#'   \itemize{
#'     \item{\code{id}} {identification number}
#'     \item{\code{pluralty}} {5 = single fetus}
#'     \item{\code{outcome}} {1 = live birth that survived at least 28 days}
#'     \item{\code{date}} {birth date where 1096=January 1, 1961}
#'     \item{\code{gestation}} {length of gestation (in days)}
#'     \item{\code{sex}} {infant's sex (1=male, 2=female)}
#'     \item{\code{wt}} {birth weight (in ounces)}
#'     \item{\code{parity}} {total number of previous pregnancies (including fetal deaths
#' and still births)}
#'     \item{\code{race}} {mother's race: 0-5=white 6=mex 7=black 8=asian 9=mixed}
#'     \item{\code{age}} {mother's age in years at termination of pregnancy}
#'     \item{\code{ed}} {mother's education:  0= less than 8th grade, 
#' 1 = 8th -12th grade - did not graduate, 
#' 2= HS graduate--no other schooling, 3= HS+trade,
#' 4=HS+some college,
#' 5=College graduate, 
#' 6=Trade school, 7=HS unclear}
#'     \item{\code{ht}} {mother's height in inches to the last completed inch}
#'     \item{\code{wt.1}} {mother's prepregnancy weight (in pounds)}
#'     \item{\code{drace}} {father's race (a factor with levels equivalent to mother's race)}
#'     \item{\code{dage}} {father's age (in years)}
#'     \item{\code{ded}} {father'ed education (same coding as mother's education)}
#'     \item{\code{dht}} {father's height in inches to the last completed inch}
#'     \item{\code{dwt}} {father's weight (in pounds)}
#'     \item{\code{marital}} {marital status: 1=married, 2=legally separated, 3=divorced,
#'   4=widowed, 5=never married}
#'     \item{\code{inc}} {family yearly income in $2500 increments: 0=under 2500,
#'   1=2500-4999, ..., 8=12,500-14,999, 9=15000+}
#'     \item{\code{smoke}} {does mother smoke? 0=never, 1=smokes now, 
#'     2=until current pregnancy, 3=once did, not now}
#'     \item{\code{time}} {time since quitting smoking: 0=never smoked, 1=still smokes,
#'     2=during current preg, 3=within 1 yr, 4=1 to 2 years ago,
#'     5= 2 to 3 yr ago, 6= 3 to 4 yrs ago, 7=5 to 9yrs ago, 
#'     8=10+yrs ago, 9=quit and don't know}
#'     \item{\code{number}} {number of cigs smoked per day for past and current smokers  0=never, 1=1-4, 2=5-9, 3=10-14, 4=15-19, 5=20-29, 6=30-39, 7=40-60, 8=60+, 9=smoke but don't know}
#'   }
#' 
#' @details 
#' The data were presented by Nolan and Speed to address the question of whether there is a link between maternal smoking and the baby's health.
#' 
#' @source 
#' The book by Nolan and Speed
#' describes the data in more detail 
#' and provides an Internet site for accessing them: 
#' \url{http://www.stat.berkeley.edu/users/statlabs/}
#' 
#' 
#' @references 
#' D Nolan and T Speed. \emph{Stat Labs: Mathematical 
#' Statistics Through Applications} (2000), Springer-Verlag.
#' 
#' @examples 
#' data(Gestation)
#' 
#' @keywords datasets

NA



#' Health Evaluation and Linkage to Primary Care
#' 
#' The HELP study was a clinical trial for adult inpatients recruited from a
#' detoxification unit.  Patients with no primary care physician were randomized
#' to receive a multidisciplinary assessment and a brief motivational intervention
#' or usual care, with the goal of linking them to primary medical care.
#' 
#' @keywords datasets
#' @name HELPfull
#' @usage data(HELPfull)
#' @docType data
#' @format 
#'   A data frame with 1472 observations on the following variables.
#'   \itemize{
#'     \item{\code{ID}} {Subject ID}
#'     \item{\code{TIME}} {Interview time point}
#'     \item{\code{NUM_INTERVALS}} {Number of 6-month intervals from previous to current interview}
#'     \item{\code{INT_TIME1}} {# of months from baseline to current interview}
#'     \item{\code{DAYS_SINCE_BL}} {# of days from baseline to current interview}
#'     \item{\code{INT_TIME2}} {# of months from previous to current interview}
#'     \item{\code{DAYS_SINCE_PREV}} {# of days from previous to current interview}
#'     \item{\code{PREV_TIME}} {Previous interview time}
#'     \item{\code{DEAD}} {a numeric vector}
#'     \item{\code{A1}} {Gender (1=Male, 2=Female)}
#'     \item{\code{A9}} {Years of education completed}
#'     \item{\code{A10}} {Marital Status (1=Married, 2=Remarried, 3=Widowed, 4= Separated, 5=Divorced, 6=Never Married}
#'     \item{\code{A11A}} {Do you currently have a living mother? (0=No, 1= Yes}
#'     \item{\code{A11B}} {Do you currently have a living father? (0=No, 1=Yes}
#'     \item{\code{A11C}} {Do you currently have siblings? (0=No, 1=Yes}
#'     \item{\code{A11D}} {Do you currently have a partner (0=No, 1=Yes)}
#'     \item{\code{A11E}} {Do you currently have children? (0=No, 1=Yes)}
#'     \item{\code{A12B}} {Hollingshead categories (1=Major profess, 2= Lesser profess, 3=Minor profess, 4=Clerical/sales, 5=Skilled manual, 6=Semi-skilled, 7=Unskilled, 8= Homemaker, 9=No occupation)}
#'     \item{\code{A13}} {Usual employment pattern in last 6 months (1=Full time, 2= Part time, 3=Student, 4=Unemployed, 5=Control envir)}
#'     \item{\code{A14A}} {Loved alone-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{A14B}} {Lived w/a partner-last 6 mos (0=No, 1=Yes}
#'     \item{\code{A14C}} {Lived with parent(s)-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{A14D}} {Lived w/children-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{A14E}} {Lived w/other family-last 6 mos (0=No, 1=Yes}
#'     \item{\code{A14F}} {Lived w/friend(s)-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{A14G}} {Lived w/other-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{A14G_T}} {a factor with levels \code{} \code{1/2 WAY HOUSE} \code{3/4 HOUSE} \code{ANCHOR INN} \code{ARMY} \code{ASSOCIATES} \code{BOARDERS} \code{BOYFRIENDS MOM} \code{CORRECTIONAL FACILIT} \code{CRACK HOUSE} \code{DEALER} \code{ENTRE FAMILIA} \code{FENWOOD} \code{GAVIN HSE} \code{GIRLFRIENDS DAUGHTE} \code{GIRLFRIENDS SON} \code{GIRLFRIENDS CHILDREN} \code{GIRLFRIENDS DAUGHTER} \code{GROUP HOME} \code{HALF-WAY HOUSE} \code{HALFWAY HOUSE} \code{HALFWAY HOUSES} \code{HALFWAY HSE} \code{HOLDING UNIT} \code{HOME BORDER} \code{HOMELESS} \code{HOMELESS SHELTER} \code{IN JAIL} \code{IN PROGRAMS} \code{INCARCERATED} \code{JAIL} \code{JAIL HALFWAY HOUSE} \code{JAIL, SHELTER} \code{JAIL, STREET} \code{JAIL/PROGRAM} \code{JAIL/SHELTER} \code{JAILS} \code{LANDLADY} \code{LANDLORD} \code{LODGING HOUSE} \code{MERIDIAN HOUSE} \code{NURSING HOME} \code{ON THE STREET} \code{PARTNERS MOTHER} \code{PARTNERS CHILD} \code{PARTNERS CHILDREN} \code{PRDGRAMS} \code{PRISON} \code{PROGRAM} \code{PROGRAM MTHP} \code{PROGRAM ROOMMATES} \code{PROGRAM SOBER HOUSE} \code{PROGRAM-RESIDENTIAL} \code{PROGRAM/HALFWAY HOUS} \code{PROGRAM/JAIL} \code{PROGRAM/SHELTER} \code{PROGRAM/SHELTERS} \code{PROGRAMS} \code{PROGRAMS SUBSTANCE} \code{PROGRAMS/SHELTER} \code{PROGRAMS/SHELTERS} \code{PROGRAMS/SHELTERS/DE} \code{PROJECT SOAR} \code{RESIDENTIAL FACILITY} \code{RESIDENTIAL PROGRAM} \code{ROOMING HOUSE} \code{ROOMING HOUSE (RELIG} \code{ROOMMATE} \code{ROOMMATES} \code{ROOMMATES AT TRANSIT} \code{RYAN HOUSE} \code{SALVATION ARMY} \code{SHELTER} \code{SHELTER/HALFWAY HSE} \code{SHELTER/HOTEL} \code{SHELTER/PROGRAM} \code{SHELTERS} \code{SHELTERS/HOSPITALS} \code{SHELTERS/JAIL} \code{SHELTERS/PROGRAMS} \code{SHELTERS/STREETS} \code{SOBER HOUSE} \code{SOBER HOUSING} \code{SOUTH BAY JAIL} \code{STEPSON} \code{STREET} \code{STREETS} \code{SUBSTANCE ABUSE TREA} \code{TRANSITIONAL HOUSE} \code{VA SHELTER}}
#'     \item{\code{A15A}} {#nights in ovrnight shelter-last 6 mos}
#'     \item{\code{A15B}} {# nights on street-last 6 mos}
#'     \item{\code{A15C}} {#months in jail-last 6 mos}
#'     \item{\code{A16A}} {# months in ovrnight shelter-last 5 yrs}
#'     \item{\code{A16B}} {#moths on street-last 5 yrs}
#'     \item{\code{A16C}} {#months in jail-last 5 yrs}
#'     \item{\code{A17A}} {Received SSI-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{A17B}} {Received SSDI-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{A17C}} {Received AFDC-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{A17D}} {Received EAEDC-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{A17E}} {Received WIC-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{A17F}} {Received unemployment benefits-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{A17G}} {Received Workman's Comp-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{A17H}} {Received Child Support-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{A17I}} {Received other income-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{A17I_T}} {a factor with levels \code{} \code{DISABLED VETERAN} \code{EBT (FOOD STAMPS)} \code{EMERGENCY FOOD STAMP} \code{FOOD STAMP} \code{FOOD STAMPS} \code{FOOD STAMPS/VETERAN} \code{FOOD STAMPS/VETERANS} \code{INSURANCE SETTLEMENT} \code{PENSION CHECK} \code{SECTION 8} \code{SERVICE CONNECTED DI} \code{SOCIAL SECURITY} \code{SSDI FOR SON} \code{SURVIVORS BENEFITS} \code{TEMPORARY DISABILITY} \code{VA BENEFITS-DISABILI} \code{VA COMPENSATION} \code{VA DISABILITY PENSIO} \code{VETERAN BENEFITS} \code{VETERANS SERVICES} \code{VETERANS AFFAIRS}}
#'     \item{\code{A18}} {Most money made in any 1 year-last 5 yrs (1=<5000, 2=5000-10000, 3=11000-19000, 4=20000-29000, 5=30000-39000, 6=40000-49000, 7=50000+}
#'     \item{\code{B1}} {In general, how is your health (1=Excellent, 2=Very Good, 3=Good, 4=Fair, 5=Poor)}
#'     \item{\code{B2}} {Comp to 1 yr ago, how is your health now (1=Much better, 2=Somewhat better, 3=About the same, 4=Somewhat worse, 5=Much worse)}
#'     \item{\code{B3A}} {Does health limit you in vigorous activity (1=Limited a lot, 2=Limited a little, 3=Not limited)}
#'     \item{\code{B3B}} {Does your health limit you in moderate activity (1=Limited a lot, 2=Limited a little, 3=Not limited)}
#'     \item{\code{B3C}} {Does health limit you in lift/carry groceries (1=Limited a lot, 2=Limited a little, 3=Not limited)}
#'     \item{\code{B3D}} {Hlth limit you in climb sev stair flights (1=Limited a lot, 2=Limited a little, 3=Not limited)}
#'     \item{\code{B3E}} {Health limit you in climb 1 stair flight (1=Limited a lot, 2=Limited a little, 3=Not limited)}
#'     \item{\code{B3F}} {Health limit you in bend/kneel/stoop (1=Limited a lot, 2=Limited a little, 3=Not limited)}
#'     \item{\code{B3G}} {Does health limit you in walking >1 mile (1=Limited a lot, 2=Limited a little, 3=Not limited)}
#'     \item{\code{B3H}} {Hlth limit you in walking sevrl blocks (1=Limited a lot, 2=Limited a little, 3=Not limited)}
#'     \item{\code{B3I}} {Does health limit you in walking 1 block (1=Limited a lot, 2=Limited a little, 3=Not limited)}
#'     \item{\code{B3J}} {Hlth limit you in bathing/dressing self (1=Limited a lot, 2=Limited a little, 3=Not limited)}
#'     \item{\code{B4A}} {Cut down wrk/act due to phys hlth-lst 4 wks (0=No, 1=Yes)}
#'     \item{\code{B4B}} {Accomplish less due to phys hlth-lst 4 wks (0=No, 1=Yes)}
#'     \item{\code{B4C}} {Lim wrk/act type due to phys hlth-lst 4 wks (0=No, 1=Yes)}
#'     \item{\code{B4D}} {Diff perf work due to phys hlth-lst 4 wks (0=No, 1=Yes)}
#'     \item{\code{B5A}} {Cut wrk/act time due to emot prbs-lst 4 wks (0=No, 1=Yes)}
#'     \item{\code{B5B}} {Accomplish ess due to emot probs-lst 4 wks (0=No, 1=Yes)}
#'     \item{\code{B5C}} {<carefl w/wrk/act due to em prb-lst 4 wks (0=No, 1=Yes)}
#'     \item{\code{B6}} {Ext phys/em intf w/norm soc act-lst 4 wk (1-Not al all, 2=Slightly, 3=Moderately, 4=Quite a bit, 5=Extremely)}
#'     \item{\code{B7}} {Amount of bodily pain-past 4 wks (1=None, 2=Very mild, 3= Mild, 4=Moderate, 5= Severe, 6= Very severe)}
#'     \item{\code{B8}} {Amt pain interf with norm work-last 4 wks (1=Not at all, 2=A little bit, 3=Moderately, 4=Quite a bit, 5=Extremely}
#'     \item{\code{B9A}} {Did you feel full of pep-past 4 wks (1=All of the time, 2=Most of the time, 3 = Good bit of the time, 4=Some of the time, 5=A little of time, 6=None of the time)}
#'     \item{\code{B9B}} {Have you been nervous-past 4 wks (1=All of the time, 2=Most of the time, 3 = Good bit of the time, 4=Some of the time, 5=A little of time, 6=None of the time)}
#'     \item{\code{B9C}} {Felt nothing could cheer you-lst 4 wks (1=All of the time, 2=Most of the time, 3 = Good bit of the time, 4=Some of the time, 5=A little of time, 6=None of the time)}
#'     \item{\code{B9D}} {Have you felt calm/peaceful-past 4 wks (1=All of the time, 2=Most of the time, 3 = Good bit of the time, 4=Some of the time, 5=A little of time, 6=None of the time)}
#'     \item{\code{B9E}} {Did you have a lot of energy-past 4 wks (1=All of the time, 2=Most of the time, 3 = Good bit of the time, 4=Some of the time, 5=A little of time, 6=None of the time)}
#'     \item{\code{B9F}} {Did you feel downhearted-past 4 wks (1=All of the time, 2=Most of the time, 3 = Good bit of the time, 4=Some of the time, 5=A little of time, 6=None of the time)}
#'     \item{\code{B9G}} {Did you feel worn out-past 4 wks (1=All of the time, 2=Most of the time, 3 = Good bit of the time, 4=Some of the time, 5=A little of time, 6=None of the time)}
#'     \item{\code{B9H}} {Have you been a happy pers-past 4 wks (1=All of the time, 2=Most of the time, 3 = Good bit of the time, 4=Some of the time, 5=A little of time, 6=None of the time)}
#'     \item{\code{B9I}} {Did you feel tired-past 4 wks (1=All of the time, 2=Most of the time, 3 = Good bit of the time, 4=Some of the time, 5=A little of time, 6=None of the time)}
#'     \item{\code{B10}} {Amyphys/em prb intf w/soc act-lst 4 wks (1All of the time, 2=Most of the time, 3=Some of the time, 4= A lttle of time, 5= Non of the time)}
#'     \item{\code{B11A}} {I seem to get sick easier than oth peop (1=Definitely true, 2=Mostly True, 3=Don't know, 4=Mostly false, 5=Definitely false)}
#'     \item{\code{B11B}} {I am as healthy as anybody I know (1=Definitely true, 2=Mostly true, 3=Don't know, 4=Mostly false, 5=Definitely False)}
#'     \item{\code{B11C}} {I expect my health to get worse (1=Definitely true, 2=Mostly true, 3=Don't know, 3=Mostly false, 5=Definitely false)}
#'     \item{\code{B11D}} {My health is excellent (1=Definitely true, 2=Mostly true, 3=Don't know, 4=Mostly false, 5=Definitely false)}
#'     \item{\code{C1A}} {Tolf by MD had seix, epil, convuls (0=No, 1=Yes)}
#'     \item{\code{C1B}} {Told by MD had asth, emphys, chr lung dis (0=No, 1=Yes)}
#'     \item{\code{C1C}} {Told by MD had MI (0=No, 1=Yes)}
#'     \item{\code{C1D}} {Told by MD had CHF (0=No, 1=Yes)}
#'     \item{\code{C1E}} {Told by MD had other heart dis (req med) (0=No, 1=Yes)}
#'     \item{\code{C1F}} {Told by MD had HBP (0=No, 1=Yes)}
#'     \item{\code{C1G}} {Told by MD had chronic liver disease (0=No, 1=Yes)}
#'     \item{\code{C1H}} {Told by MD had kidney failure (0=No, 1=Yes)}
#'     \item{\code{C1I}} {Told by MD had chronic art, osteoarth (0=No, 1=Yes)}
#'     \item{\code{C1J}} {Told by MD had peripheral neuropathy (0=No, 1=Yes)}
#'     \item{\code{C1K}} {Ever told by MD had cancer (0=No, 1=Yes)}
#'     \item{\code{C1L}} {Ever told by MD had diabetes (0=No, 1=Yes)}
#'     \item{\code{C1M}} {Ever told by MD had stroke (0=No, 1=Yes)}
#'     \item{\code{C2A1}} {Have you ever had skin infections (0=No, 1=Yes)}
#'     \item{\code{C2A2}} {Have you had skin infections-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2B1}} {Have you ever had pneumonia (0=No, 1=Yes)}
#'     \item{\code{C2B2}} {Have you had pneumonia-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2C1}} {Have you ever had septic arthritis (0=No, 1=Yes)}
#'     \item{\code{C2C2}} {Have you had septic arthritis-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2D1}} {Have you ever had TB (0=No, 1=Yes)}
#'     \item{\code{C2D2}} {Have you had TB-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2E1}} {Have you ever had endocarditis (0=No, 1=Yes)}
#'     \item{\code{C2E2}} {Have you had endocarditis-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2F1}} {Have you ever had an ulcer (0=No, 1=Yes)}
#'     \item{\code{C2F2}} {Have you had an ulcer-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2G1}} {Have you ever had pancreatitis  (0=No, 1=Yes)}
#'     \item{\code{C2G2}} {Have you had pancreatitis-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2H1}} {Ever had abdom pain req overnt hosp stay (0=No, 1=Yes)}
#'     \item{\code{C2H2}} {Abdom pain req ovrnt hosp stay-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2I1}} {Have you ever vomited blood (0=No, 1=Yes)}
#'     \item{\code{C2I2}} {Have you vomited blood-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2J1}} {Have you ever had hepatitis (0=No, 1=Yes)}
#'     \item{\code{C2J2}} {Have you had hepatitis-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2K1}} {Ever had blood clots in legs/lungs (0=No, 1=Yes)}
#'     \item{\code{C2K2}} {Blood clots in legs/lungs-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2L1}} {Have you ever had osteomyelitis (0=No, 1=Yes)}
#'     \item{\code{C2L2}} {Have you had osteomyelitis-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2M1}} {Chst pain using cocaine req ER/hosp (0=No, 1=Yes)}
#'     \item{\code{C2M2}} {Chst pain using coc req ER/hosp-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2N1}} {Have you ever had jaundice (0=No, 1=Yes)}
#'     \item{\code{C2N2}} {Have you had jaundice-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2O1}} {Lower back pain > 3mos req med attn (0=No, 1=Yes)}
#'     \item{\code{C2O2}} {Lwr bck pain >3mos req med attn-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2P1}} {Ever had seizures or convulsions (0=No, 1=Yes)}
#'     \item{\code{C2P2}} {Had seizures or convulsions-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2Q1}} {Ever had drug/alc overdose req ER attn (0=No, 1=Yes)}
#'     \item{\code{C2Q2}} {Drug/alc overdose req ER attn (0=No, 1=Yes)}
#'     \item{\code{C2R1}} {Have you ever had a gunshot wound (0=No, 1=Yes)}
#'     \item{\code{C2R2}} {Had a gunshot wound-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2S1}} {Have you ever had a stab wound (0=No, 1=Yes)}
#'     \item{\code{C2S2}} {Have you had a stab wound-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2T1}} {Ever had accid/falls req med attn (0=No, 1=Yes)}
#'     \item{\code{C2T2}} {Had accid/falls req med attn-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2U1}} {Ever had fract/disloc to bones/joints (0=No, 1=Yes)}
#'     \item{\code{C2U2}} {Fract/disloc to bones/joints-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2V1}} {Ever had injury from traffic accident (0=No, 1=Yes)}
#'     \item{\code{C2V2}} {Had injury from traffic accid-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C2W1}} {Have you ever had a head injury (0=No, 1=Yes)}
#'     \item{\code{C2W2}} {Have you had a head injury-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{C3A1}} {Have you ever had syphilis (0=No, 1=Yes)}
#'     \item{\code{C3A2}} {# times had syphilis}
#'     \item{\code{C3A3}} {Have you had syphilis in last 6 mos (0=No, 1=Yes)}
#'     \item{\code{C3B1}} {Have you ever had gonorrhea (0=No, 1=Yes)}
#'     \item{\code{C3B2}} {# times had gonorrhea}
#'     \item{\code{C3B3}} {Have you had gonorrhea in last 6 mos (0=No, 1=Yes)}
#'     \item{\code{C3C1}} {Have you ever had chlamydia (0=No, 1=Yes)}
#'     \item{\code{C3C2}} {# of times had Chlamydia}
#'     \item{\code{C3C3}} {Have you had chlamydia in last 6 mos (0=No, 1=Yes)}
#'     \item{\code{C3D}} {Have you ever had genital warts (0=No, 1=Yes)}
#'     \item{\code{C3E}} {Have you ever had genital herpes (0=No, 1=Yes)}
#'     \item{\code{C3F1}} {Have you ever had other STD's (not HIV) (0=No, 1=Yes)}
#'     \item{\code{C3F2}} {# of times had other STD's (not HIV)}
#'     \item{\code{C3F3}} {Had other STD's (not HIV)-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{C3F_T}} {a factor with levels \code{} \code{7} \code{CRABS} \code{CRABS - TRICHONOMIS} \code{CRABS, HEP B} \code{DOESNT KNOW NAME} \code{HAS HAD ALL 3  ABC} \code{HEP B} \code{HEP B, TRICAMONAS} \code{HEP. B} \code{HEPATITIS B} \code{HEPATITS B} \code{TRICHAMONAS VAGINALA} \code{TRICHAMONIS} \code{TRICHOMONAS} \code{TRICHOMONIASIS} \code{TRICHOMONIS} \code{TRICHOMONIS VAGINITI} \code{TRICHOMORAS} \code{TRICHONOMIS}}
#'     \item{\code{C3G1}} {Have you ever been tested for HIV/AIDS (0=No, 1=Yes)}
#'     \item{\code{C3G2}} {# times tested for HIV/AIDS}
#'     \item{\code{C3G3}} {Have you been tested for HIV/AIDS-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{C3G4}} {What was the result of last test (1=Positive, 2=Negative, 3=Refued, 4=Never got result, 5=Inconclusive}
#'     \item{\code{C3H1}} {Have you ever had PID (0=No, 1=Yes)}
#'     \item{\code{C3H2}} {# of times had PID}
#'     \item{\code{C3H3}} {Have you had PID in last 6 mos (0=No, 1=Yes)}
#'     \item{\code{C3I}} {Have you ever had a Pap smear (0=No, 1=Yes)}
#'     \item{\code{C3J}} {Have you had a Pap smear in last 3 years (0=No, 1=Yes)}
#'     \item{\code{C3K}} {Are you pregnant (0=No, 1=Yes)}
#'     \item{\code{C3K_M}} {How many mos pregnant}
#'     \item{\code{D1}} {$ of times hospitalized for med probs}
#'     \item{\code{D2}} {Take prescr med regularly for phys prob (0=No, 1=Yes)}
#'     \item{\code{D3}} {# days had med probs-30 days bef detox}
#'     \item{\code{D4}} {How bother by med prob-30days bef detox (0=Not at all, 1=Slightly, 2=Moderately, 3=Considerably, 4=Extremely)}
#'     \item{\code{D5}} {How import is trtmnt for these med probs (0=Not at all, 1=Slightly, 2= Moderately, 3= Considerably, 4= Extremely}
#'     \item{\code{E2A}} {Detox prog for alc or drug prob-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E2B}} {# times entered a detox prog-lst 6 mos}
#'     \item{\code{E2C}} {# nights ovrnight in detox prg-lst 6 mos}
#'     \item{\code{E3A}} {Holding unit for drug/alc prob-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E3B}} {# times in holding unity=lst 6 mos}
#'     \item{\code{E3C}} {# total nights in holding unit-lst 6 mos}
#'     \item{\code{E4A}} {In halfway hse/resid facil-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E4B}} {# times in hlfwy hse/res facil-lst 6 mos}
#'     \item{\code{E4C}} {Ttl nites in hlfwy hse/res fac-last 6 mos}
#'     \item{\code{E5A}} {In day trtmt prg for alcohol/drug-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E5B}} {Total # days in day trtmt prg-lst 6 mos}
#'     \item{\code{E6}} {In methadone maintenance prg-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E7A}} {Visit outpt prg subst ab couns-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E7B}} {# visits outpt prg subst ab couns-lst 6 mos}
#'     \item{\code{E8A1}} {Saw MD/H care wkr re alcohol/drugs-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E8A2}} {Saw Prst/Min/Rabbi re alcohol/drugs-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E8A3}} {Employ Asst Prg for alcohol/drug prb-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E8A4}} {Oth source cnsl for alcohol/drug prb-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E9A}} {AA/NA/slf-hlp for drug/alcohol/emot-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E9B}} {How often attend AA/NA/slf-hlp-lst 6 mos (1=Daily, 2=2-3 Times/week, 3=Weekly, 4=Every 2 weeks, 5=Once/month}
#'     \item{\code{E10A}} {have you been to med clinic-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E10B1}} {# x visit ment hlth clin/prof-lst 6 mos}
#'     \item{\code{E10B2}} {# x visited med clin/priv MD-lst 6 mos}
#'     \item{\code{E10C19}} {Visited private MD-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{E11A}} {Did you stay ovrnite/+ in hosp-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E11B}} {# times ovrnight/+ in hosp-last 6 mos }
#'     \item{\code{E11C}} {Total # nights in hosp-last 6 mos}
#'     \item{\code{E12A}} {Visited Hosp ER for med care-past 6 mos (0=No, 1=Yes)}
#'     \item{\code{E12B}} {# times visited hosp ER-last 6 mos}
#'     \item{\code{E13}} {Tlt # visits to MDs-lst 2 wks bef detox}
#'     \item{\code{E14A}} {Recd trtmt from acupuncturist-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{E14B}} {Recd trtmt from chiropractor-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{E14C}} {Trtd by hol/herb/hom med prac-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E14D}} {Recd trtmt from spirit healer-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E14E}} {Have you had biofeedback-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{E14F}} {Have you underwent hypnosis-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E14G}} {Received other treatment-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{E15A}} {Tried to get subst ab services-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{E15B}} {Always able to get subst ab servies (0=No, 1=Yes)}
#'     \item{\code{E15C1}} {I could not pay for services (0=No, 1=Yes)}
#'     \item{\code{E15C2}} {I did not know where to go for help (0=No, 1=Yes)}
#'     \item{\code{E15C3}} {Couldn't get to services due to transp prob (0=No, 1=Yes)}
#'     \item{\code{E15C4}} {The offie/clinic hrs were inconvenient (0=No, 1=Yes)}
#'     \item{\code{E15C5}} {Didn't speak/understnd Englsh well enough (0=No, 1=Yes)}
#'     \item{\code{E15C6}} {Afraid other might find out about prob (0=No, 1=Yes)}
#'     \item{\code{E15C7}} {My substance abuse interfered (0=No, 1=Yes)}
#'     \item{\code{E15C8}} {Didn't have someone to watch my children (0=No, 1=Yes)}
#'     \item{\code{E15C9}} {I did not want to lose my job (0=No, 1=Yes)}
#'     \item{\code{E15C10}} {My insurance didn't cover services (0=No, 1=Yes)}
#'     \item{\code{E15C11}} {There were no beds available at the prog (0=No, 1=Yes)}
#'     \item{\code{E15C12}} {Other reason not get sub ab services (0=No, 1=Yes)}
#'     \item{\code{E16A1}} {I cannot pay for services (0=No, 1=Yes)}
#'     \item{\code{E16A2}} {I am not eligible for free care (0=No, 1=Yes)}
#'     \item{\code{E16A3}} {I do not know where to go (0=No, 1=Yes)}
#'     \item{\code{E16A4}} {Can't get to services due to trans prob (0=No, 1=Yes)}
#'     \item{\code{E16A5}} {a numeric vectorOffice/clinic hours are inconvenient (0=No, 1=Yes)}
#'     \item{\code{E16A6}} {I don't speak/understnd enough English (0=No, 1=Yes)}
#'     \item{\code{E16A7}} {Afraid othrs find out about my hlth prob (0=No, 1=Yes)}
#'     \item{\code{E16A8}} {My substance abuse interferes (0=No, 1=Yes)}
#'     \item{\code{E16A9}} {I don't have someone to watch my childrn (0=No, 1=Yes)}
#'     \item{\code{E16A10}} {I do not want to lose my job (0=No, 1=Yes)}
#'     \item{\code{E16A11}} {My insurance doesn't cover charges (0=No, 1=Yes)}
#'     \item{\code{E16A12}} {I do not feel I need a regular MD (0=No, 1=Yes)}
#'     \item{\code{E16A13}} {Other reasons don't have regular MD (0=No, 1=Yes)}
#'     \item{\code{E18A}} {I could not pay for services (0=No, 1=Yes)}
#'     \item{\code{E18B}} {I did not know where to go for help (0=No, 1=Yes)}
#'     \item{\code{E18C}} {Couldn't get to services due to transp prob (0=No, 1=Yes)}
#'     \item{\code{E18D}} {The office/clinic hrs were inconvenient (0=No, 1=Yes)}
#'     \item{\code{E18F}} {Afraid others might find out about prob (0=No, 1=Yes)}
#'     \item{\code{E18G}} {My substance abuse interfered (0=No, 1=Yes)}
#'     \item{\code{E18H}} {Didn't have someone to watch my children (0=No, 1=Yes)}
#'     \item{\code{E18I}} {I did not want to lose my job (0=No, 1=Yes)}
#'     \item{\code{E18J}} {My insurance didn't cover services (0=No, 1=Yes)}
#'     \item{\code{E18K}} {There were no beds available at the prog (0=No, 1=Yes)}
#'     \item{\code{E18L}} {I do not need substance abuse services (0=No, 1=Yes)}
#'     \item{\code{E18M}} {Other reason not get sub ab services (0=No, 1=Yes)}
#'     \item{\code{F1A}} {Bothered by thngs not gen boethered by (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1B}} {My appretite was poor (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1C}} {Couldn't shake blues evn w/fam+frnds hlp (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1D}} {Felt I was just as good as other people (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1E}} {Had trouble keeping mind on what doing (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1F}} {I felt depressed (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1G}} {I felt everthing I did was an effort (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1H}} {I felt hopeful about the future (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1I}} {I thought my life had been a failure (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1J}} {I felt fearful (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1K}} {My sleep was restless (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1L}} {I was happy (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1M}} {I talked less than usual (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1N}} {I felt lonely (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1O}} {People were unfriendly (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1P}} {I enoyed life (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1Q}} {I had crying spells (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1R}} {I felt sad (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1S}} {I felt that people dislike me (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{F1T}} {I could not get going (0=Rarely/never, 1=Some of the time, 2=Occas/moderately, 3=Most of the time)}
#'     \item{\code{G1A}} {Diff contr viol beh for sig time per evr (0=No, 1=Yes)}
#'     \item{\code{G1A_30}} {Diff contr viol beh-sig per lst 30 days (0=No, 1=Yes)}
#'     \item{\code{G1B}} {Ever had thoughts of suicide (0=No, 1=Yes)}
#'     \item{\code{G1B_30}} {Had thoughts of suicide-lst 30 days (0=No, 1=Yes)}
#'     \item{\code{G1C}} {Attempted suicide ever (0=No, 1=Yes)}
#'     \item{\code{G1C_30}} {Attempted suicide-lst 30 days (0=No, 1=Yes)}
#'     \item{\code{G1D}} {Prescr med for pst/emot prob ever (0=No, 1=Yes)}
#'     \item{\code{G1D_30}} {Prescr med for psy/emot prob-lst 30 days (0=No, 1=Yes)}
#'     \item{\code{H1_30}} {# days in past 30 bef detox used alcohol}
#'     \item{\code{H1_LT}} {# yrs regularly used alcohol}
#'     \item{\code{H1_RT}} {Route of administration use alcohol (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H2_30}} {#days in 3- bef detox use alc to intox}
#'     \item{\code{H2_LT}} {# yrs regularly used alcohol to intox}
#'     \item{\code{H2_RT}} {Route of admin use alcohol to intox (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H3_30}} {# days in past 30 bef detox used heroin}
#'     \item{\code{H3_LT}} {# yrs regularly used heroin}
#'     \item{\code{H3_RT}} {Route of administration of heroin (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H4_30}} {# days used methadone-lst 30 bef detox}
#'     \item{\code{H4_LT}} {# yrs regularly used methadone}
#'     \item{\code{H4_RT}} {Route of administration of methadone (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H5_30}} {# days used opi/analg-lst 30 bef detox}
#'     \item{\code{H5_LT}} {# yrs regularly used oth opiates/analg}
#'     \item{\code{H5_RT}} {Route of admin of oth opiates/analg (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H6_30}} {# days in past 30 bef detox used barbit}
#'     \item{\code{H6_LT}} {# yrs regularly used barbiturates}
#'     \item{\code{H6_RT}} {Route of admin of barbiturates (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H7_30}} {# days used sed/hyp/trnq-lst 30 bef det}
#'     \item{\code{H7_LT}} {# yrs regularly used sed/hyp/trnq}
#'     \item{\code{H7_RT}} {Route of admin of sed/hyp/trnq (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H8_30}} {# days in lst 30 bef detox used cocaine}
#'     \item{\code{H8_LT}} {# yrs regularly used cocaine}
#'     \item{\code{H8_RT}} {Route of admin of cocaine (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H9_30}} {# days in lst 30 bef detox used amphet}
#'     \item{\code{H9_LT}} {# yrs regularly used amphetamines}
#'     \item{\code{H9_RT}} {Route of admin of amphetamines (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H10_30}} {# days in lst 30 bef detox used cannabis}
#'     \item{\code{H10_LT}} {# yrs regularly used cannabis}
#'     \item{\code{H10_RT}} {Route of admin of cannabis (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H11_30}} {# days in lst 30 bef detox used halluc}
#'     \item{\code{H11_LT}} {# yrs regularly used hallucinogens}
#'     \item{\code{H11_RT}} {Route of admin of hallucinogens (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H12_30}} {# days in lst 30 bef detox used inhalant}
#'     \item{\code{H12_LT}} {# yrs regularly used inhalants}
#'     \item{\code{H12_RT}} {Route of admin of inhalants (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H13_30}} {# days used >1 sub/day-lst 30 bef detox}
#'     \item{\code{H13_LT}} {# yrs regularly used >1 subst/day}
#'     \item{\code{H13_RT}} {Route of admin of >1 subst/day (0=N/A. 1=Oral, 2=Nasal, 3=Smoking, 4=Non-IV injection, 5=IV)}
#'     \item{\code{H14}} {Accord to interview w/c subst is main prob (0=No problem, 1=Alcohol, 2=Alcool to intox, 3=Heroin 4=Methadone, 5=Oth opiate/analg, 6=Barbituates, 7=Sed/hyp/tranq, 8=Cocaine, 9=Amphetamines, 10=Marij/cannabis}
#'     \item{\code{H15A}} {# times had alchol DTs}
#'     \item{\code{H15B}} {# times overdosed on drugs}
#'     \item{\code{H16A}} {$ spent on alc-lst 30 days bef detox}
#'     \item{\code{H16B}} {$ spent on drugs-lst 30 days bef detox}
#'     \item{\code{H17A}} {# days had alc prob-lst 30 days bef det}
#'     \item{\code{H17B}} {# days had drug prob-lst 30 days bef det}
#'     \item{\code{H18A}} {How troubled by alc probs-lst 30 days (0=Not at all, 1=Slightly, 2=Moderately, 3=Considerably, 4=Extremely)}
#'     \item{\code{H18B}} {How troubled by drug probs-lst 30 days (0=Not at all, 1=Slightly, 2=Moderately, 3=Considerably, 4=Extremely)}
#'     \item{\code{H19A}} {How import is trtmnt for alc probs now (0=Not at all, 1=Slightly, 2=Moderately, 3=Considerably, 4=Extremely)}
#'     \item{\code{H19B}} {How importy is trtmnt for drug probs now (0=Not at all, 1=Slightly, 2=Moderately, 3=Considerably, 4=Extremely)}
#'     \item{\code{I1}} {Avg # drinks in lst 30 days bef detox}
#'     \item{\code{I2}} {Most drank any 1 day in lst 30 bef detox}
#'     \item{\code{I3}} {On days used heroin, avg # bags used}
#'     \item{\code{I4}} {Most bgs heroin use any 1 day-30 bef det}
#'     \item{\code{I5}} {Avg $ amt of heorin used per day}
#'     \item{\code{I6A}} {On days used cocaine, avg # bags used}
#'     \item{\code{I6B}} {On days used cocaine, avg # rocks used}
#'     \item{\code{I7A}} {Mst bgs cocaine use any 1 day-30 bef det}
#'     \item{\code{I7B}} {Mst rcks cocaine use any 1 day-30 bef det}
#'     \item{\code{I8}} {Avg $ amt of cocaine used per day}
#'     \item{\code{J1}} {Evr don't stop using cocaine when should (0=No, 1=Yes)}
#'     \item{\code{J2}} {Ever tried to cut down on cocaine (0=No, 1=Yes)}
#'     \item{\code{J3}} {Does cocaine take up a lot of your time (0=No, 1=Yes)}
#'     \item{\code{J4}} {Need use > cocaine to get some feeling (0=No, 1=Yes)}
#'     \item{\code{J5A}} {Get phys sick when stop using cocaine (0=No, 1=Yes)}
#'     \item{\code{J5B}} {Ever use cocaine to prevent getting sick (0=No, 1=Yes)}
#'     \item{\code{J6}} {Ever don't stop using heroin when should (0=No, 1=Yes)}
#'     \item{\code{J7}} {Ever tried to cut down on heroin (0=No, 1=Yes)}
#'     \item{\code{J8}} {Does heroin take up a lot of your time (0=No, 1=Yes)}
#'     \item{\code{J9}} {Need use > heroin to get some feeling (0=No, 1=Yes)}
#'     \item{\code{J10A}} {Get phys sick when stop using heroin (0=No, 1=Yes)}
#'     \item{\code{J10B}} {Ever use heroin to prevent getting sick (0=No, 1=Yes)}
#'     \item{\code{K1}} {Do you currently smoke cigarettes (1=Yes-every day, 2=Yes-some days, 3=No-former smoker, 4=No-never>100 cigs}
#'     \item{\code{K2}} {Avg # cigarettes smoked per day}
#'     \item{\code{K3}} {Considering quitting cigs w/in next 6 mo (0=No, 1=Yes)}
#'     \item{\code{L1}} {How often drink last time drank (1=To get high/less, 2=To get drunk, 3=To pass out)}
#'     \item{\code{L2}} {Often have hangovrs Sun or Mon mornings (0=No, 1=Yes)}
#'     \item{\code{L3}} {Have you had the shakes when sobering (0=No, 1=Sometimes, 2=Alm evry time drink)}
#'     \item{\code{L4}} {Do you get phys sick as reslt of drinking (0=No, 1=Sometimes, 2=Alm evry time drink)}
#'     \item{\code{L5}} {have you had the DTs (0=No, 1=Once, 2=Several times}
#'     \item{\code{L6}} {When drink do you stumble/stagger/weave (0=No, 1=Sometimes, 2=Often)}
#'     \item{\code{L7}} {D/t drinkng felt overly hot/sweaty (0=No, 1=Once, 2=Several times)}
#'     \item{\code{L8}} {As result of drinkng saw thngs not there (0=No, 1=Once, 2=Several times)}
#'     \item{\code{L9}} {Panic because fear not have drink if need it (0=No, 1=Yes)}
#'     \item{\code{L10}} {Have had blkouts as result of drinkng (0=No, never, 1=Sometimes, 2=Often, 3=Alm evry time drink)}
#'     \item{\code{L11}} {Do you carry bottle or keep close by (0=No, 1=Some of the time, 2=Most of the time)}
#'     \item{\code{L12}} {After abstin end up drink heavily again (0=No, 1=Sometimes, 2=Almost evry time)}
#'     \item{\code{L13}} {Passed out due to drinking-lst 12 mos (0=No, 1=Once, 2=More than once)}
#'     \item{\code{L14}} {Had convuls following period of drinkng (0=No, 1=Once, 2=Several times)}
#'     \item{\code{L15}} {Do you drink throughout the day (0=No, 1=Yes)}
#'     \item{\code{L16}} {Aftr drinkng heavily was thinkng unclear (0=No, 1=Yes, few hrs, 2=Yes,1-2 days, 3=Yes, many days)}
#'     \item{\code{L17}} {D/t drinkng felt heart beat rapidly (0=No, 1=Once, 2=Several times)}
#'     \item{\code{L18}} {Do you constntly think about drinkng/alc (0=No, 1=Yes)}
#'     \item{\code{L19}} {D/t drinkng heard things not there (0=No, 1=Once, 2= Several times)}
#'     \item{\code{L20}} {Had weird/fright sensations when drinkng (0=No, 1=Once or twice, 2=Often)}
#'     \item{\code{L21}} {When drinkng felt things rawl not there (0=No, 1=Once, 2=Several times)}
#'     \item{\code{L22}} {With respect to blackouts (0=Never had one, 1=Had for <1hr, 2=Had several hrs, 3=Had for day/+)}
#'     \item{\code{L23}} {Ever tried to cut down on drinking & failed (0=No, 1=Once, 2=Several times)}
#'     \item{\code{L24}} {Do you gulp drinks (0=No, 1=Yes)}
#'     \item{\code{L25}} {After taking 1 or 2 drinks can you stop (0=No, 1=Yes)}
#'     \item{\code{M1}} {Had hangover/felt bad aftr using alcohol/drugs (0=No, 1=Yes)}
#'     \item{\code{M2}} {Felt bad about self because of alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M3}} {Missed days wrk/sch because of alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M4}} {Fam/frinds worry/compl about alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M5}} {I have enjoyed drinking/using drugs (0=No, 1=Yes)}
#'     \item{\code{M6}} {Qual of work suffered because of alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M7}} {Parenting ability harmed by alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M8}} {Trouble sleeping/nightmares aftr alcohol/drugs (0=No, 1=Yes)}
#'     \item{\code{M9}} {Driven motor veh while undr inf alcohol/drugs (0=No, 1=Yes)}
#'     \item{\code{M10}} {Using alcohol/1 drug caused > use othr drugs (0=No, 1=Yes)}
#'     \item{\code{M11}} {I have been sick/vomited aft alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M12}} {I have been unhappy because of alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M13}} {Lost weight/eaten poorly due to alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M14}} {Fail to do what expected due to alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M15}} {Using alcohol/drugs has helped me to relax (0=No, 1=Yes)}
#'     \item{\code{M16}} {Felt guilt/ashamed because of my alc drug use (0=No, 1=Yes)}
#'     \item{\code{M17}} {Said/done emarras thngs when on alcohol/drug (0=No, 1=Yes)}
#'     \item{\code{M18}} {Personality changed for worse on alcohol/drug (0=No, 1=Yes)}
#'     \item{\code{M19}} {Taken foolish risk when using alcohol/drugs (0=No, 1=Yes)}
#'     \item{\code{M20}} {Gotten into trouble because of alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M21}} {Said cruel things while using alcohol/drugs (0=No, 1=Yes)}
#'     \item{\code{M22}} {Done impuls thngs regret due to alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M23}} {Gotten in phys fights when use alcohol/drugs (0=No, 1=Yes)}
#'     \item{\code{M24}} {My phys health was harmed by alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M25}} {Using alcohol/drug helped me have more + outlook (0=No, 1=Yes)}
#'     \item{\code{M26}} {I have had money probs because of my alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M27}} {My love relat harmed due to my alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M28}} {Smoked tobacco more when using alcohol/drugs (0=No, 1=Yes)}
#'     \item{\code{M29}} {<y phys appearance harmed by alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M30}} {My family hurt because of my alc drug use (0=No, 1=Yes)}
#'     \item{\code{M31}} {Close relationsp damaged due to alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M32}} {Spent time in jail because of my alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M33}} {My sex life suffered due to my alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M34}} {Lost interst in activity due to my alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M35}} {Soc life> enjoyable when using alcohol/drug (0=No, 1=Yes)}
#'     \item{\code{M36}} {Spirit/moral life harmed by alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M37}} {Not had kind life want due to alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M38}} {My alcohol/drug use in way of personal growth (0=No, 1=Yes)}
#'     \item{\code{M39}} {My alcohol/drug use damaged soc life/reputat (0=No, 1=Yes)}
#'     \item{\code{M40}} {Spent/lost too much $ because alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M41}} {Arrested for DUI of alc or oth drugs (0=No, 1=Yes)}
#'     \item{\code{M42}} {Arrested for offenses rel to alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M43}} {Lost marriage/love relat due to alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M44}} {Susp/fired/left job/sch due to alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M45}} {I used drugs moderately w/o having probs (0=No, 1=Yes)}
#'     \item{\code{M46}} {I have lost a friend due to my alcohol/drug use (0=No, 1=Yes)}
#'     \item{\code{M47}} {Had an accident while using alcohol/drugs (0=No, 1=Yes)}
#'     \item{\code{M48}} {Phys hurt/inj/burned when using alcohol/drugs (0=No, 1=Yes)}
#'     \item{\code{M49}} {I injured someone while using alcohol/drugs (0=No, 1=Yes)}
#'     \item{\code{M50}} {Damaged things/prop when using alcohol/drugs (0=No, 1=Yes)}
#'     \item{\code{N1A}} {My friends give me the moral support I need (0=No, 1=Yes)}
#'     \item{\code{N1B}} {Most people closer to friends than I am (0=No, 1=Yes)}
#'     \item{\code{N1C}} {My friends enjoy hearing what I think (0=No, 1=Yes)}
#'     \item{\code{N1D}} {I rely on my friends for emot support (0=No, 1=Yes)}
#'     \item{\code{N1E}} {Friend go to when down w/o feel funny later (0=No, 1=Yes)}
#'     \item{\code{N1F}} {Frnds and I open re what thnk about things (0=No, 1=Yes)}
#'     \item{\code{N1G}} {My friends sensitive to my pers needs (0=No, 1=Yes)}
#'     \item{\code{N1H}} {My friends good at helping me solve probs (0=No, 1=Yes)}
#'     \item{\code{N1I}} {have deep sharing relat w/ a # of frnds (0=No, 1=Yes)}
#'     \item{\code{N1J}} {When confide in frnds makes me uncomfort (0=No, 1=Yes)}
#'     \item{\code{N1K}} {My friends seek me out for companionship (0=No, 1=Yes)}
#'     \item{\code{N1L}} {Not have as int relat w/frnds as others (0=No, 1=Yes)}
#'     \item{\code{N1M}} {Recent good idea how to do somethng frm frnd (0=No, 1=Yes)}
#'     \item{\code{N1N}} {I wish my friends were much different (0=No, 1=Yes)}
#'     \item{\code{N2A}} {My family gives me the moral support I need (0=No, 1=Yes)}
#'     \item{\code{N2B}} {Good ideas of how do/make thngs from fam (0=No, 1=Yes)}
#'     \item{\code{N2C}} {Most peop closer to their fam than I am (0=No, 1=Yes)}
#'     \item{\code{N2D}} {When confide make close fam membs uncomf (0=No, 1=Yes)}
#'     \item{\code{N2E}} {My fam enjoys hearing about what I think (0=No, 1=Yes)}
#'     \item{\code{N2F}} {Membs of my fam share many of my intrsts (0=No, 1=Yes)}
#'     \item{\code{N2G}} {I rely on my fam for emot support (0=No, 1=Yes)}
#'     \item{\code{N2H}} {Fam memb go to when down w/o feel funny (0=No, 1=Yes)}
#'     \item{\code{N2I}} {Fam and I open about what thnk about thngs (0=No, 1=Yes)}
#'     \item{\code{N2J}} {My fam is sensitive to my personal needs (0=No, 1=Yes)}
#'     \item{\code{N2K}} {Fam memb good at helping me solve probs (0=No, 1=Yes)}
#'     \item{\code{N2L}} {Have deep sharing relat w/# of fam membs (0=No, 1=Yes)}
#'     \item{\code{N2M}} {Makes me uncomf to confide in fam membs (0=No, 1=Yes)}
#'     \item{\code{N2N}} {I wish my family were much different (0=No, 1=Yes)}
#'     \item{\code{O1A}} {# people spend tx w/who drink alc (1=None, 2= A few, 3=About half, 4= Most, 5=All)}
#'     \item{\code{O1B}} {# people spend tx w/who are heavy drinkrs (1=None, 2= A few, 3=About half, 4= Most, 5=All)}
#'     \item{\code{O1C}} {# people spend tx w/who use drugs (1=None, 2= A few, 3=About half, 4= Most, 5=All)}
#'     \item{\code{O1D}} {# peop spend tx w/who supprt your abstin (1=None, 2= A few, 3=About half, 4= Most, 5=All)}
#'     \item{\code{O2}} {Does live-in part/spouse drink/use drugs (0=No, 1=Yes, 2=N/A)}
#'     \item{\code{P1A}} {Phys abuse/assaul by fam memb/pers know (0=No, 1=Yes, 7=Not sure)}
#'     \item{\code{P1B}} {Age first phys assaulted by pers know}
#'     \item{\code{P1C}} {Phys assaulted by pers know-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{P2A}} {Phys abuse/assaul by stranger (0=No, 1=Yes, 7=Not sure)}
#'     \item{\code{P2B}} {Age first phys assaulted by stranger}
#'     \item{\code{P2C}} {Phys assaulted by stranger-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{P3}} {Using drugs/alc when phys assaulted (1=Don't know, 2=Never, 3=Some cases, 4=Most cases, 5=All cases, 9=Never assaulted)}
#'     \item{\code{P4}} {Pers who phys assault you using alcohol/drugs (1=Don't know, 2=Never, 3=Some cases, 4=Most cases, 5=All cases, 9=Never assaulted)}
#'     \item{\code{P5A}} {Sex abuse/assual by fam memb/pers know (0=No, 1= Yes, 7=Not sure)}
#'     \item{\code{P5B}} {Age first sex assaulted by pers know}
#'     \item{\code{P5C}} {Sex assaulted by pers know-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{P6A}} {Sex abuse/assaul by stranger (0=No, 1=Yes, 7=Not sure)}
#'     \item{\code{P6B}} {Age first sex assaulted by stranger}
#'     \item{\code{P6C}} {Sex assaulted by stranger-last 6 mos (0=No, 1=Yes)}
#'     \item{\code{P7}} {Using drugs/alc when sex assaulted (1=Don't know, 2=Never, 3=Some cases, 4=Most cases, 5=All cases, 9=Never assaulted)}
#'     \item{\code{P8}} {Person who sex assaulted you using alcohol/drugs (1=Don't know, 2=Never, 3=Some cases, 4=Most cases, 5=All cases, 9=Never assaulted)}
#'     \item{\code{Q1A}} {Have you ever injected drugs (0=No, 1=Yes)}
#'     \item{\code{Q1B}} {Have you injected drugs-lst 6 mos (0=No, 1=Yes)}
#'     \item{\code{Q2}} {Have you shared needles/works-last 6 mos (0=No/Not shot up, 3=Yes)}
#'     \item{\code{Q3}} {# people shared needles w/past 6 mos (0=No/Not shot up, 1=1 other person, 2=2-3 diff people, 3=4/+ diff people)}
#'     \item{\code{Q4}} {How often been to shoot gall/hse-lst 6 mos (0=Never, 1=Few times or less, 2= Few times/month, 3= Once or more/week)}
#'     \item{\code{Q5}} {How often been to crack house-last 6 mos (0=Never, 1=Few times or less, 2=Few times/month, 3=Once or more/week)}
#'     \item{\code{Q6}} {How often shared rinse-water-last 6 mos (0=Nevr/Not shot up, 1=Few times or less, 2=Few times/month, 3=Once or more/week)}
#'     \item{\code{Q7}} {How often shared a cooker-last 6 mos (0=Nevr/Not shot up, 1=Few times or less, 2=Few times/month, 3=Once or more/week)}
#'     \item{\code{Q8}} {How often shared a cotton-last 6 mos (0=Nevr/Not shot up, 1=Few times or less, 2=Few times/month, 3=Once or more/week)}
#'     \item{\code{Q9}} {How often use syringe to div drugs-lst 6 mos (0=Nevr/Not shot up, 1=Few times or less, 2=Few times/month, 3=Once or more/week)}
#'     \item{\code{Q10}} {How would you describe yourself (0=Straight, 1=Gay/bisexual)}
#'     \item{\code{Q11}} {# men had sex w/in past 6 months (0=0 men, 1=1 man, 2=2-3 men, 3=4+ men}
#'     \item{\code{Q12}} {# women had sex w/in past 6 months (0=0 women, 1=1woman, 2=2-3 women, 3=4+ women}
#'     \item{\code{Q13}} {# times had sex In past 6 mos (0=Never, 1=Few times or less, 2=Few times/month, 3=Once or more/week)}
#'     \item{\code{Q14}} {How often had sex to get drugs-last 6 mos (0=Never, 1=Few times or less, 2=Few times/month, 3=Once or more/week)}
#'     \item{\code{Q15}} {How often given drugs to have sex-lst 6 mos (0=Never, 1=Few times or less, 2=Few times/month, 3=Once or more/week)}
#'     \item{\code{Q16}} {How often were you paid for sex-lst 6 mos (0=Never, 1=Few times or less, 2=Few times/month, 3=Once or more/week)}
#'     \item{\code{Q17}} {How often you pay pers for sex-lst 6 mos (0=Never, 1=Few times or less, 2=Few times/month, 3=Once or more/week)}
#'     \item{\code{Q18}} {How often use condomes during sex=lst 6 mos (0=No sex/always, 1=Most of the time, 2=Some of the time, 3=None of the time)}
#'     \item{\code{Q19}} {Condoms are too much of a hassle to use (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{Q20}} {Safer sex is always your responsibility (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1A}} {I really want to hange my alcohol/drug use (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1B}} {Sometimes I wonder if I'm an alcohol/addict (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1C}} {Id I don't chng alcohol/drug probs will worsen (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1D}} {I started making changes in alcohol/drug use (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1E}} {Was using too much but managed to change (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1F}} {I wonder if my alcohol/drug use hurting othrs (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1G}} {I am a prob drinker or have drug prob (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1H}} {Already doing thngs to chnge alcohol/drug use (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1I}} {have changed use-trying to not slip back (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1J}} {I have a serious problem w/ alcohol/drugs (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1K}} {I wonder if I'm in contrl of alcohol/drug use (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1L}} {My alcohol/drug use is causing a lot of harm (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1M}} {Actively curring down/stopping alcohol/drug use (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1N}} {Want help to not go back to alcohol/drugs (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1O}} {I know that I have an alcohol/drug problem (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1P}} {I wonder if I use alcohol/drugs too much (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1Q}} {I am an alcoholic or drug addict (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1R}} {I am working hard to change alcohol/drug use (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{R1S}} {Some changes-want help from going back (1=Strongly disagree, 2=Disagree, 3= Agree, 4=Strongly agree)}
#'     \item{\code{S1A}} {At interview pt obviously depressed/withdrawn (0=No, 1=Yes)}
#'     \item{\code{S1B}} {at interview pt obviously hostile (0=No, 1=Yes)}
#'     \item{\code{S1C}} {At interview pt obviouslt anx/nervous (0=No, 1=Yes)}
#'     \item{\code{S1D}} {Trouble w/real tst/thght dis/par at interview (0=No, 1=Yes)}
#'     \item{\code{S1E}} {At interview pt trbl w/ compr/concen/rememb (0=No, 1=Yes)}
#'     \item{\code{S1F}} {At interview pt had suicidal thoughts (0=No, 1=Yes)}
#'     \item{\code{T1}} {Have used alc since leaving River St. (0=No, 1=Yes)}
#'     \item{\code{T1B}} {# days in row continued to drink}
#'     \item{\code{T1C}} {Longest period abstain-lst 6 mos (alc)}
#'     \item{\code{T2}} {Have used heroin since leaving River St (0=No, 1=Yes)}
#'     \item{\code{T2B}} {# days in row continued to use heroin}
#'     \item{\code{T2C}} {Longest period abstain-lst 6 mos (heroin)}
#'     \item{\code{T3}} {Have used cocaine since leaving River St (0=No, 1=Yes)}
#'     \item{\code{T3B}} {# days in row continued to use cocaine}
#'     \item{\code{T3C}} {Lngest period abstain-lst 6 mos (cocaine)}
#'     \item{\code{U1}} {It is important to have a regular MD (1=Strongly agree, 2=Agree, 3=Uncertain, 4=Disagree, 5=Strongly Disagree)}
#'     \item{\code{U2A}} {I cannot pay for services (0=No, 1=Yes)}
#'     \item{\code{U2B}} {I am not eligible for free care (0=No, 1=Yes)}
#'     \item{\code{U2C}} {I do not know where to go (0=No, 1=Yes)}
#'     \item{\code{U2D}} {Can't get services due to transport probs (0=No, 1=Yes)}
#'     \item{\code{U2E}} {Office/clinic hours are inconvenient (0=No, 1=Yes)}
#'     \item{\code{U2F}} {I do not speak/understand English well (0=No, 1=Yes)}
#'     \item{\code{U2G}} {Afraid others discover hlth prb I have (0=No, 1=Yes)}
#'     \item{\code{U2H}} {My substance abuse interferes (0=No, 1=Yes)}
#'     \item{\code{U2I}} {I do not have a babysitter (0=No, 1=Yes)}
#'     \item{\code{U2J}} {I do not want to lose my job (0=No, 1=Yes)}
#'     \item{\code{U2K}} {My insurance does not cover services (0=No, 1=Yes)}
#'     \item{\code{U2L}} {Medical care is not important to me (0=No, 1=Yes)}
#'     \item{\code{U2M}} {I do not have time (0=No, 1=Yes)}
#'     \item{\code{U2N}} {Med staff do not treat me with respect (0=No, 1=Yes)}
#'     \item{\code{U2O}} {I do not trust my doctors or nurses (0=No, 1=Yes)}
#'     \item{\code{U2P}} {Often been unsatisfied w/my med care (0=No, 1=Yes)}
#'     \item{\code{U2Q}} {Other reason hard to get regular med care (0=No, 1=Yes)}
#'     \item{\code{U2Q_T}} {a factor with many levels}
#'     \item{\code{U2R}} {a factor with levels \code{} \code{7} \code{A} \code{B} \code{C} \code{D} \code{E} \code{F} \code{G} \code{H} \code{I} \code{J} \code{K} \code{L} \code{M} \code{N} \code{O} \code{P} \code{Q}}
#'     \item{\code{U3A}} {Has MD evr talked to you about drug use (0=No, 1=Yes)}
#'     \item{\code{U3B}} {Has MD evr talked to you about alc use (0=No, 1=Yes)}
#'     \item{\code{U4}} {Is there an MD you consider your regular MD (0=No, 1=Yes)}
#'     \item{\code{U5}} {Have you seen any MDs in last 6 mos (0=No, 1=Yes)}
#'     \item{\code{U6A}} {Would you go to this MD if med prb not emer (0=No, 1=Yes)}
#'     \item{\code{U6B}} {Think one of these could be your regular MD (0=No, 1=Yes)}
#'     \item{\code{PCP_ID}} {a numeric vector}
#'     \item{\code{U7A}} {What type of MD is your regular MD/this MD (1=OB/GYN, 2=Family medicine, 3=Pediatrician, 4=Adolescent medicine, 5=Internal medicine, 6=AIDS doctor, 7=Asthma doctor, 8=Pulmonary doctor, 9=Cardiologist, 10=Gastroen)}
#'     \item{\code{U7A_T}} {a factor with levels \code{} \code{ARTHRITIS DOCTOR} \code{CHIROPRACTOR} \code{COCAINE STUDY} \code{DETOX DOCTOR} \code{DO} \code{EAR DOCTOR} \code{EAR SPECIALIST} \code{EAR, NOSE, & THROAT.} \code{EAR/NOSE/THROAT} \code{ENT} \code{FAMILY PHYSICIAN} \code{GENERAL MEDICINE} \code{GENERAL PRACTICE} \code{GENERAL PRACTIONER} \code{GENERAL PRACTITIONER} \code{HEAD & NECK SPECIALIST} \code{HERBAL/HOMEOPATHIC/ACUPUNCTURE} \code{ID DOCTOR} \code{MAYBE GENERAL PRACTITIONER} \code{MEDICAL STUDENT} \code{NEUROLOGIST} \code{NURSE} \code{NURSE PRACTICIONER} \code{NURSE PRACTITIONER} \code{ONCOLOGIST} \code{PRENATAL} \code{PRIMARY} \code{PRIMARY CAAE} \code{PRIMARY CARE} \code{PRIMARY CARE DOCTOR} \code{PRIMERY CARE} \code{THERAPIST} \code{UROLOGIST} \code{WOMENS CLINIC BMC}}
#'     \item{\code{U8A}} {Only saw this person once (=Only saw once)}
#'     \item{\code{U8B}} {Saw this person for <6 mos (1=<6 mos)}
#'     \item{\code{U8C}} {Saw tis person for 6 mos-1year (2=Betwn 6 mos & 1 yr)}
#'     \item{\code{U8D}} {Saw this person for 1-2 years (3=1-2 years)}
#'     \item{\code{U8E}} {Saw this person for 3-5 years (4=3-5 years)}
#'     \item{\code{U8F}} {Saw this person for more than 5 years (5=>5 years)}
#'     \item{\code{U10A}} {# times been to regular MDs office-pst 6 mos}
#'     \item{\code{U10B}} {# times saw regular MD in office-pst 6 mos}
#'     \item{\code{U10C}} {# times saw oth prof in office-pst 6 mos}
#'     \item{\code{U11}} {Rate convenience of MD office location (1=Very poor, 2=Poor, 3=Fair, 4=Good, 5=Very good, 6=Excellent)}
#'     \item{\code{U12}} {Rate hours MD office open for med appts (1=Very poor, 2=Poor, 3=Fair, 4=Good, 5=Very good, 6=Excellent)}
#'     \item{\code{U13}} {Usual wait for appt when sick (unsched) (1=Very poor, 2=Poor, 3=Fair, 4=Good, 5=Very good, 6=Excellent)}
#'     \item{\code{U14}} {Time wait for appt to start at MD office (1=Very poor, 2=Poor, 3=Fair, 4=Good, 5=Very good, 6=Excellent)}
#'     \item{\code{U15A}} {DO you pay for any/all of MD visits (0=No, 1=Yes)}
#'     \item{\code{U15B}} {How rate amt of $ you pay for MD visits (1=Very poor, 2=Poor, 3=Fair, 4=Good, 5=Very good, 6=Excellent)}
#'     \item{\code{U16A}} {Do you pay for any/all of prescript meds (0=No, 1=Yes)}
#'     \item{\code{U16B}} {Rate amt $ pay for meds/prescript trtmnts (1=Very poor, 2=Poor, 3=Fair, 4=Good, 5=Very good, 6=Excellent)}
#'     \item{\code{U17}} {Ever skip meds/trtmnts because too expensive (1=Yes, often, 2=Yes, occasionally, 3=No, never)}
#'     \item{\code{U18A}} {Ability to reach MC office by phone (1=Very poor, 2=Poor, 3=Fair, 4=Good, 5=Very good, 6=Excellent)}
#'     \item{\code{U18B}} {Ability to speak to MD by phone if need (1=Very poor, 2=Poor, 3=Fair, 4=Good, 5=Very good, 6=Excellent)}
#'     \item{\code{U19}} {How often see regular MD when have regular check-up (1=Always, 2=Almost always, 3=A lot of the time, 4=Some of the time, 5=Almost never, 6=Never)}
#'     \item{\code{U20}} {When sick + go to MD how often see regular MD (1=Always, 2=Almost always, 3=A lot of the time, 4=Some of the time, 5=Almost never, 6=Never)}
#'     \item{\code{U21A}} {How thorough MD exam to check hlth prb (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U21B}} {How often question if MD diagnosis right (1=Always, 2=Almost always, 3=A lot of the time, 4=Some of the time, 5=Almost never, 6=Never)}
#'     \item{\code{U22A}} {Thoroughness of MD questions re symptoms (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U22B}} {Attn MD gives to what you have to say (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U22C}} {MD explanations of hlth prbs/trtmnts need (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U22D}} {MD instrcts re sympt report/further care (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U22E}} {MD advice in decisions about your care (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U23}} {How often leave MD office w/unanswd quests (1=Always, 2=Almost always, 3=A lot of the time, 4=Some of the time, 5=Almost never, 6=Never)}
#'     \item{\code{U24A}} {Amount of time your MD spends w/you (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U24B}} {MDs patience w/ your questions/worries (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U24C}} {MDs friendliness and warmth toward you (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U24D}} {MDs caring and concern for you (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U24E}} {MDs respect for you (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U25A}} {Reg MD ever talked to you about smoking (0=No, 1=Yes)}
#'     \item{\code{U25B}} {Reg MD ever talked to you about alc use (0=No, 1=Yes)}
#'     \item{\code{U25C}} {Reg MD ever talk to you about seat belt use (0=No, 1=Yes)}
#'     \item{\code{U25D}} {Reg MD ever talked to you about diet (0=No, 1=Yes)}
#'     \item{\code{U25E}} {Reg Mdever talked to you about exercise (0=No, 1=Yes)}
#'     \item{\code{U25F}} {Reg MD ever talked to you about stress (0=No, 1=Yes)}
#'     \item{\code{U25G}} {Reg MD ever talked to you about safe sex (0=No, 1=Yes)}
#'     \item{\code{U25H}} {Reg MD ever talked to you about drug use (0=No, 1=Yes)}
#'     \item{\code{U25I}} {Reg MD ever talked to you about HIV testing (0=No, 1=Yes)}
#'     \item{\code{U26A}} {Cut/quit smoking because of MDs advice (0=No, 1=Yes)}
#'     \item{\code{U26B}} {Tried to drink less alcohol because of MD advice (0=No, 1=Yes)}
#'     \item{\code{U26C}} {Wore my seat belt more because of MDs advice (0=No, 1=Yes)}
#'     \item{\code{U26D}} {Changed diet because of MDs advice (0=No, 1=Yes)}
#'     \item{\code{U26E}} {Done more exercise because MDs advice (0=No, 1=Yes)}
#'     \item{\code{U26F}} {Relax/reduce stress because of MDs advice (0=No, 1=Yes)}
#'     \item{\code{U26G}} {Practiced safer sex because of MDs advice (0=No, 1=Yes)}
#'     \item{\code{U26H}} {Tried to cut down/quit drugs because MD advice (0=No, 1=Yes)}"						
#'     \item{\code{U26I}} {Got HIV tested because of MDs advice (0=No, 1=Yes)}"						
#'     \item{\code{U27A}} {I can tell my MD anything (1=Strongly agree, 2= Agree, 3= Not sure, 4=Disagree, 5=Strongly disagree)}"						
#'     \item{\code{U27B}} {My MD pretends to know thngs if not sure (1=Strongly agree, 2= Agree, 3= Not sure, 4=Disagree, 5=Strongly disagree)}"						
#'     \item{\code{U27C}} {I trust my MDs judgement re my med care (1=Strongly agree, 2= Agree, 3= Not sure, 4=Disagree, 5=Strongly disagree)}"						
#'     \item{\code{U27D}} {My MD cares > about < costs than my hlth (1=Strongly agree, 2= Agree, 3= Not sure, 4=Disagree, 5=Strongly disagree)}"						
#'     \item{\code{U27E}} {My MD always tell truth about my health (1=Strongly agree, 2= Agree, 3= Not sure, 4=Disagree, 5=Strongly disagree)}"						
#'     \item{\code{U27F}} {My MD cares as much as I about my hlth (1=Strongly agree, 2= Agree, 3= Not sure, 4=Disagree, 5=Strongly disagree)}"						
#'     \item{\code{U27G}} {My MD would try to hide a mistake in trtmt (1=Strongly agree, 2= Agree, 3= Not sure, 4=Disagree, 5=Strongly disagree)}"						
#'     \item{\code{U28}} {How much to you trst this MD (0=Not at all, 1=1, 2=2, 3=3, 4=4, 5=5, 6=6, 7=7, 8=8, 9=9, 10=Completely)}"						
#'     \item{\code{U29A}} {MDs knowledge of your entire med history (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}"						
#'     \item{\code{U29B}} {MD knowldg of your respons-home/work/sch (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}"						
#'     \item{\code{U29C}} {MD knowldg of what worries you most-hlth (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}"						
#'     \item{\code{U29D}} {MDs knowledge of you as a person (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}"						
#'     \item{\code{U30}} {MD would know what want done if unconsc (1=Strongly agree, 2=Agree, 3=Not sure, 4= Disagree, 5=Strongly disagree)}"						
#'     \item{\code{U31}} {Oth MDs/RNs who play roel in your care (0=No, 1=Yes)}"						*
#'     \item{\code{U32A}} {Their knowledge of you as a person (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U32B}} {The quality of care they provide (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U32C}} {Coordination betw them and your regular MD (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U32D}} {Their expl of your hlth prbs/trtmts need (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U32D_T}} {N/A, only my regular MD does this}
#'     \item{\code{U33}} {Amt regular MD knows about care from others (1=Knows everything, 2=Knows almost everything, 3=Knows some things, 4=Knows very little, 5=Knows nothing)}
#'     \item{\code{U34}} {Has MD ever recommended you see MD sepcialist (0=No, 1=Yes)}
#'     \item{\code{U35A}} {How helpful MD in deciding on specialist (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U35B}} {How helpful MD getting appt w/specialist (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U35C}} {MDs involvmt when you trtd by specialist (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U35D}} {MDs communic w/your specialists/oth MDs (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U35E}} {MD help in explain what specialists said (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U35F}} {Quality of specialists MD sent you to (1=Very poor, 2= Poor, 3=Fair, 4=Good, 5= Very good, 6= Excellent)}
#'     \item{\code{U36}} {How many minutes to get to MDs office (1=<15, 2=16-30. 3=31-60, 4=More than 60)}
#'     \item{\code{U37}} {When sick+call how long take to see you (1=Same day, 2=Next day, 3=In 2-3 days, 4=In 4-5 days, 5=in >5 days)}
#'     \item{\code{U38}} {How mant minutes late appt usually begin (1=None, 2=<5 minutes, 3=6-10 minutes, 4=11-20 minutes, 5=21-30 minutes, 6=31-45 minutes, 7=>45 minutes)}
#'     \item{\code{U39}} {How satisfied are you w/your regular MD (1=Completely satisfied, 2=Very satisfied, 3=Somewhat satisfied, 4=Neither, 5=Somewhat dissatisfied, 6=Very dissatisfied, 7=Completely dissatisfied)}
#'     \item{\code{V1}} {Evr needed to drink much more to get effect (0=No, 1=Yes)}
#'     \item{\code{V2}} {Evr find alc had < effect than once did (0=No, 1=Yes)}
#'     \item{\code{Z1}} {Breath Alcohol Concentration:1st test}
#'     \item{\code{Z2}} {Breath Alcohol Concentration:2nd test}
#'     \item{\code{AGE}} {Age in years}
#'     \item{\code{REALM}} {REALM score}
#'     \item{\code{E16A_RT}} {Barrier to regular MD: red tape (0=No, 1=Yes)}
#'     \item{\code{E16A_IB}} {Barrier to regular MD: internal barriers (0=No, 1=Yes)}
#'     \item{\code{E16A_TM}} {Barrier to regular MD: time restrictions (0=No, 1=Yes)}
#'     \item{\code{E16A_DD}} {Barrier to regular MD: dislike docs/system (0=No, 1=Yes)}
#'     \item{\code{GROUP}} {Randomization Group (0=Control, 1=Clinic)}
#'     \item{\code{MMSEC}} {MMSEC}
#'     \item{\code{PRIM_SUB}} {First drug of choice (0=None, 1=Alcohol, 3=Cocaine, 3=Heroine, 4=Barbituates, 5=Benzos, 6=Marijuana, 7=Methadone, 8=Opiates)}
#'     \item{\code{SECD_SUB}} {Second drug of choice (0=None, 1=Alcohol, 3=Cocaine, 3=Heroine, 4=Barbituates, 5=Benzos, 6=Marijuana, 7=Methadone, 8=Opiates)}
#'     \item{\code{ALCOHOL}} {1st/2nd drug of coice=Alcohol (0=No, 1=Yes)}
#'     \item{\code{COC_HER}} {1st/2nd drug of choice=cocaine or heroine (0=No, 1=Yes)}
#'     \item{\code{REALM2}} {REALM score (dichotomous) (1=0-60, 2=61-66)}
#'     \item{\code{REALM3}} {REALM score (categorical) (1=0-44), 2=45-60), 3=61-66)}
#'     \item{\code{RACE}} {Race (recode) (1=Afr Amer/Black, 2=White, 3=Hispanic, 4=Other)}
#'     \item{\code{RACE2}} {Race (recode) (1=White, 2=Minority)}
#'     \item{\code{BIRTHPLC}} {Where born (recode) (0=USA, 1=Foreign)}
#'     \item{\code{PRIMLANG}} {First language (recode) (0=English, 1=Other lang)}
#'     \item{\code{MD_LANG}} {Lang prefer to speak to MD (recode) (0=English, 1=Other lang)}
#'     \item{\code{HS_GRAD}} {High school graduate (0=No, 1=Yes)}
#'     \item{\code{MAR_STAT}} {Marital status (recode) (0=Married, 1=Not married)}
#'     \item{\code{A12B_REC}} {Hollingshead category (recode) (0=Cat 1,2,3, 1=Cat 4,5,6, 2=Cat 7,8,9)}
#'     \item{\code{UNEMPLOY}} {Usually unemployed last 6m (0=No, 1=Yes)}
#'     \item{\code{ALONE6M}} {Usually lived alone past 6m y/n (0=No, 1=Yes)}
#'     \item{\code{HOMELESS}} {Homeless-shelter/street past 6 m (0=No, 1=Yes)}
#'     \item{\code{JAIL_MOS}} {Total months in jail past 5 years }
#'     \item{\code{JAIL_5YR}} {Any jail time past 5 years y/n (0=No, 1=Yes)}
#'     \item{\code{GOV_SUPP}} {Received governemtn support past 6 m (0=No, 1=Yes)}
#'     \item{\code{A18_REC1}} {Most money made in 1 yr (recode)  (0=$19,000 or less, 1=$20,000-$49,000, 2=$50,000 or more)}
#'     \item{\code{A18_REC2}} {Most money made-continuous recode}
#'     \item{\code{STD_EVER}} {Ever had an STD y/n (0=No, 1=Yes)}
#'     \item{\code{STD_6M}} {Had an STD past 6m y/n (0=No, 1=Yes)}
#'     \item{\code{CHR_SUM}} {Sum chronic medican conds/HIV ever}
#'     \item{\code{CHR_EVER}} {Chronic medical conds/HIV-ever y/n (0=No, 1=Yes)}
#'     \item{\code{EPI_SUM}} {Sum episodic (C2A-C2O, C2R-C2U, STD)-6m}
#'     \item{\code{EPI_6M}} {Episodic (C2A-C2O,C2R-C2U, STD)-6m y/n (0=No, 1=Yes)}
#'     \item{\code{EPI_6M2B}} {Episodic(C2A-C2O)-6m y/n (0=No, 1=Yes)}
#'     \item{\code{SER_INJ}} {Recent (6m) serious injury y/n (0=No, 1=Yes)}
#'     \item{\code{D3_REC}} {Any medical problems past 30d y/n (0=No, 1=Yes)}
#'     \item{\code{D4_REC}} {Bothered by medical problems y/n (0=No, 1=Yes)}
#'     \item{\code{D5_REC}} {Medical trtmt is important y/n (0=No, 1=Yes)}
#'     \item{\code{ANY_INS}} {Did you have health insurance past 6 m (0=No, 1=Yes)}
#'     \item{\code{FRML_SAT}} {Formal substance abuse treatment y/n (0=No, 1=Yes)}
#'     \item{\code{E10B1_R}} {Mental health treatment past 6m y/n (0=No, 1=Yes)}
#'     \item{\code{E10B2_R}} {Med clinic/private MD past 6m y/n (0=No, 1=Yes)}
#'     \item{\code{ALT_TRT}} {Alternative tratments y/n (0=No, 1=Yes)}
#'     \item{\code{ANY_UTIL}} {Amy recent health utilization (0=No, 1=Yes)}
#'     \item{\code{NUM_BARR}} {# of perceived barriers to linkage}
#'     \item{\code{G1B_REC}} {Suicidal thoughs past 30 days y/n (0=No, 1=Yes)}
#'     \item{\code{G1D_REC}} {Prescribed psych meds past 30 daus y/n (0=No, 1=Yes)}
#'     \item{\code{PRIMSUB2}} {First drug of choice (no marijuana) (0=None, 1=Alcohol, 2=Cocaine, 3=Heroin, 4=Barbituates, 5=Benzos, 6=Marijuana, 7=Methadone, 8=Opiates)}
#'     \item{\code{ALCQ_30}} {Total number drinks past 30 days}
#'     \item{\code{H2_PRB}} {Problem sub: alc to intox (0=No, 1=Yes)}
#'     \item{\code{H3_PRB}} {Problem sub: heroin (0=No, 1=Yes)}
#'     \item{\code{H4_PRB}} {Problem sub: methadone (0=No, 1=Yes)}
#'     \item{\code{H5_PRB}} {Problem sub: oth opiates/analg (0=No, 1=Yes)}
#'     \item{\code{H6_PRB}} {Problem sub: barbituates (0=No, 1=Yes)}
#'     \item{\code{H7_PRB}} {Problem sub: sedat/hyp/tranq (0=No, 1=Yes)}
#'     \item{\code{H8_PRB}} {Problem sub: cocaine (0=No, 1=Yes)}
#'     \item{\code{H9_PRB}} {Problem sub: amphetamines (0=No, 1=Yes)}
#'     \item{\code{H10_PRB}} {Problem sub: marijuana, cannabis (0=No, 1=Yes)}
#'     \item{\code{H11_PRB}} {Problem sub: hallucinogens (0=No, 1=Yes)}
#'     \item{\code{H12_PRB}} {Problem sub: inhalants (0=No, 1=Yes)}
#'     \item{\code{POLYSUB}} {Polysubstance abuser y/n (0=No, 1=Yes)}
#'     \item{\code{SMOKER}} {Current smoker (every/some days) y/n (0=No, 1=Yes)}
#'     \item{\code{O1B_REC}} {Family/friends heavy drinkers y/n (0=No, 1=Yes)}
#'     \item{\code{O1C_REC}} {Family/friends use drugs y/n (0=No, 1=Yes)}
#'     \item{\code{O1D_REC}} {Family/fiends support abst. y/n (0=No, 1=Yes)}
#'     \item{\code{O2_REC}} {Live-in partner drinks/drugs y/n (0=No, 1=Yes)}
#'     \item{\code{PHYABUSE}} {Physical abuse-stranger or family (0=No, 1=Yes)}
#'     \item{\code{SEXABUSE}} {Sexual abuse-stranger or family (0=No, 1=Yes)}
#'     \item{\code{PHSXABUS}} {Any abuse (0=No, 1=Yes)}
#'     \item{\code{ABUSE2}} {Type of abuse (0=No abuse, 1=Physical only, 2=Sexual only, 3=Physical and sexual)}
#'     \item{\code{ABUSE3}} {Type of abuse (0=No abuse, 1=Physical only, 2=Sexual +/- physical (0=No, 1=Yes)}
#'     \item{\code{CURPHYAB}} {Current abuse-physical (0=No, 1=Yes)}
#'     \item{\code{CURSEXAB}} {Current abuse-sexual (0=No, 1=Yes)}
#'     \item{\code{CURPHYSEXAB}} {Curent abuse-physical or sexual (0=No abuse, 1=Physical only, 2=Sexual +/- physical)}
#'     \item{\code{FAMABUSE}} {Family abuse-physical or sexual (0=No, 1=Yes)}
#'     \item{\code{STRABUSE}} {Stranger abuse-physical or sexual (0=No, 1=Yes)}
#'     \item{\code{ABUSE}} {Abuse-physical or sexual (0=No abuse, 1= Family abuse, 2= Stranger only abuse)}
#'     \item{\code{RAWPF}} {Raw SF-36 physical functioning}
#'     \item{\code{PF}} {SF-36 physical functioning (0-100)}
#'     \item{\code{RAWRP}} {Raw SF-36 role-physical}
#'     \item{\code{RP}} {SF-36 role physical (0-100)}
#'     \item{\code{RAWBP}} {Raw SF-36 pain index}
#'     \item{\code{BP}} {SF-36 pain index (0-100)}
#'     \item{\code{RAWGH}} {Raw SF-36 general health perceptions}
#'     \item{\code{GH}} {SF-36 general health perceptions (0-100)}
#'     \item{\code{RAWVT}} {Raw SF-36 vitality}
#'     \item{\code{VT}} {SF-36 vitality 0-100)}
#'     \item{\code{RAWSF}} {Raw SF-36 social functioning}
#'     \item{\code{SF}} {SF-36 social functioning (0-100)}
#'     \item{\code{RAWRE}} {Raw SF-36 role-emotional}
#'     \item{\code{RE}} {SF-36 role-emotional (0-100)}
#'     \item{\code{RAWMH}} {Raw SF-36 mental health index}
#'     \item{\code{MH}} {SF-36 mental health index (0-100)}
#'     \item{\code{HT}} {Raw SF-36 health transition item}
#'     \item{\code{PCS}} {Standardized physical component scale-00}
#'     \item{\code{MCS}} {Standardized mental component scale-00}
#'     \item{\code{CES_D}} {CES-D score, measure of depressive symptoms, high scores are worse}
#'     \item{\code{CESD_CUT}} {CES-D score > 21 y/n (0=No, 1=Yes)}
#'     \item{\code{C_MS}} {ASI-Composite medical status}
#'     \item{\code{C_AU}} {ASI-Composite score for alcohol use}
#'     \item{\code{C_DU}} {ASI-Composite score for drug use}
#'     \item{\code{CUAD_C}} {CUAD-Cocaine}
#'     \item{\code{CUAD_H}} {CUAD-Heroin}
#'     \item{\code{RAW_RE}} {SOCRATES-Rocognition-Raw}
#'     \item{\code{DEC_RE}} {SOCRATES-Recognition-Decile}
#'     \item{\code{RAW_AM}} {SOCRATES-Ambivalence-Raw}
#'     \item{\code{DEC_AM}} {SOCRATES-Ambivalence-Decile}
#'     \item{\code{RAW_TS}} {SOCRATES-Taking steps-Raw}
#'     \item{\code{DEC_TS}} {SOCRATES-Taking steps-Decile}
#'     \item{\code{RAW_ADS}} {ADS score}
#'     \item{\code{PHYS}} {InDUC-2L-Physical-Raw}
#'     \item{\code{PHYS2}} {InDUC-2L-Physical 9Raw (w/o M48)}
#'     \item{\code{INTER}} {InDUC-2L-Interpersonal-Raw}
#'     \item{\code{INTRA}} {InDUC-2L-Intrapersonal-Raw}
#'     \item{\code{IMPUL}} {InDUL-2L-Impulse control-Raw}
#'     \item{\code{IMPUL2}} {InDUC-2L-Impulse control-Raw (w/0 M23)}
#'     \item{\code{SR}} {InDUC-2L-Social responsibility-Raw}
#'     \item{\code{CNTRL}} {InDUC-2L-Control score}
#'     \item{\code{INDTOT}} {InDUC-2LTotal drlnC sore-Raw}
#'     \item{\code{INDTOT2}} {InDUC-2L-Total drlnC-Raw- w/o M23 and M48}
#'     \item{\code{PSS_FR}} {Perceived social support-friends}
#'     \item{\code{PSS_FA}} {Perceived social support-family}
#'     \item{\code{DRUGRISK}} {RAB-Drug risk total}
#'     \item{\code{SEXRISK}} {RAB-Sex risk total}
#'     \item{\code{TOTALRAB}} {RAB-Total RAB sore}
#'     \item{\code{RABSCALE}} {RAB scale sore}
#'     \item{\code{CHR_6M}} {Chronic medical conds/HIV-past 6m y/n (0=No, 1=Yes)}
#'     \item{\code{RCT_LINK}} {Did subject link to primary care (RCT)--This time point (0=No, 1=Yes)}
#'     \item{\code{REG_MD}} {Did subject report having regular doctor--This time point (0=No, 1=Yes)}
#'     \item{\code{ANY_VIS}} {# visits to regular doctor's office--This time point}
#'     \item{\code{ANY_VIS_CUMUL}} {Cumulative # visits to regular doctor's office}
#'     \item{\code{PC_REC}} {Primary care received: Linked & #visits (0=Not linked, 1=Linked, 1 visit, 2=Linked, 2+ visits)}
#'     \item{\code{PC_REC7}} {Primary cared received: linked & # visits (0=Not linked, 1=Linked, 1 visit, 2=Linked, 2 visits, 3=Linked, 3 visits, 4=Linked, 4 visits, 5= Linked, 5 visits, 6=Linked, 6+visits)}
#'     \item{\code{SATREAT}} {Any BSAS substance abuse this time point (0=No, 1=Yes)}
#'     \item{\code{DRINKSTATUS}} {Drank alcohol since leaving detox-6m}
#'     \item{\code{DAYSDRINK}} {Time (days) from baseline to first drink since leaving detox-6m}
#'     \item{\code{ANYSUBSTATUS}} {Used alcohol, heroin, or cocaine since leaving detox-6m}
#'     \item{\code{DAYSANYSUB}} {time (days) from baseline to first alcohol, heroin, or cocaine since leaving detox-6m}
#'     \item{\code{LINKSTATUS}} {Linked to primary care within 12 months (by administrative record)}
#'     \item{\code{DAYSLINK}} {Time (days) to linkage to primary care within 12 months (by administrative record)}
#'   }
#' 
#' @details 
#' Eligible subjects were adults, who spoke Spanish or English, reported alcohol,
#' heroin or cocaine as their first or second drug of choice, resided in proximity
#' to the primary care clinic to which they would be referred or were homeless.
#' Patients with established primary care relationships they planned to continue,
#' significant dementia, specific plans to leave the Boston area that would
#' prevent research participation, failure to provide contact information for
#' tracking purposes, or pregnancy were excluded.
#' 
#' Subjects were interviewed at baseline during their detoxification
#' stay and follow-up interviews were undertaken every 6 months for 2
#' years.  A variety of continuous, count, discrete, and survival time
#' predictors and outcomes were collected at each of these five
#' occasions.
#' 
#' This dataset is a superset of the HELPmiss and HELPrct datasets which include
#' far fewer variables.
#' 
#' @source 
#' \url{http://www.math.smith.edu/help}
#' 
#' @references 
#' Samet JH, Larson MJ, Horton NJ, Doyle K, Winter M, and Saitz R.  Linking alcohol and
#' drug-dependent adults to primary medical care:
#' A randomized controlled trial of
#' a multi-disciplinary health intervention in a detoxification unit.
#' \emph{Addiction}, 2003; 98(4):509-516.
#' 
#' 
#' @examples 
#' data(HELPfull)
#' 
#' @seealso \code{\link{HELPrct}}, and \code{\link{HELPmiss}}. 
#' 
#' @keywords datasets

NA

#' Health Evaluation and Linkage to Primary Care
#' 
#' The HELP study was a clinical trial for adult inpatients recruited from a
#' detoxification unit.  Patients with no primary care physician were randomized
#' to receive a multidisciplinary assessment and a brief motivational intervention
#' or usual care, with the goal of linking them to primary medical care.
#' 
#' @name HELPmiss
#' @usage data(HELPmiss)
#' @docType data
#' @format 
#'   Data frame with 470 observations on the following variables.  
#'   
#'   \itemize{
#'     \item{\code{age}} {subject age at baseline (in years)}
#'     \item{\code{anysub}} {use of any substance post-detox: a factor with levels \code{no} \code{yes}} 
#'     \item{\code{cesd}} {Center for Epidemiologic Studies Depression measure of depressive symptoms at baseline (higher scores indicate more symptoms)}
#'     \item{\code{d1}} {lifetime number of hospitalizations for medical problems (measured at baseline)}
#'     \item{\code{daysanysub}} {time (in days) to first use of any substance post-detox}
#'     \item{\code{dayslink}} {time (in days) to linkage to primary care}
#'     \item{\code{drugrisk}} {Risk Assessment Battery drug risk scale at baseline}
#'     \item{\code{e2b}} {number of times in past 6 months entered a detox program (measured at baseline)}
#'     \item{\code{female}} {0 for male, 1 for female} 
#'     \item{\code{sex}} {a factor with levels \code{male} \code{female}} 
#'     \item{\code{g1b}} {experienced serious thoughts of suicide in last 30 days (measured at baseline): a factor with levels \code{no} \code{yes}}
#'     \item{\code{homeless}} {housing status: a factor with levels \code{housed} \code{homeless}}
#'     \item{\code{i1}} {average number of drinks (standard units) consumed per day, in the 
#' past 30 days (measured at baseline)}
#'     \item{\code{i2}} {maximum number of drinks (standard units) consumed per day, in the 
#' past 30 days (measured at baseline)}
#'     \item{\code{id}} {subject identifier}
#'     \item{\code{indtot}} {Inventory of Drug Use Consequences (InDUC) total score (measured at baseline)}
#'     \item{\code{linkstatus}} {post-detox linkage to primary care (0 = no, 1 = yes)}
#'     \item{\code{link}} {post-detox linkage to primary care: \code{no} \code{yes}} 
#'     \item{\code{mcs}} {SF-36 Mental Component Score (measured at baseline, higher scores are better)}
#'     \item{\code{pcs}} {SF-36 Physical Component Score (measured at baseline, higher scores are better)}
#'     \item{\code{pss_fr}} {perceived social support by friends (measured at baseline)}
#'     \item{\code{racegrp}} {race/ethnicity: levels \code{black} \code{hispanic} \code{other} \code{white}}
#'     \item{\code{satreat}} {any BSAS substance abuse treatment at baseline: \code{no} \code{yes}}
#'     \item{\code{sexrisk}} {Risk Assessment Battery sex risk score (measured at baseline)}
#'     \item{\code{substance}} {primary substance of abuse: \code{alcohol} \code{cocaine} \code{heroin}}
#'     \item{\code{treat}} {randomized to HELP clinic: \code{no} \code{yes}}
#'   }
#' 
#' 
#' @details 
#' Eligible subjects were adults, who spoke Spanish or English, reported alcohol,
#' heroin or cocaine as their first or second drug of choice, resided in proximity
#' to the primary care clinic to which they would be referred or were homeless.
#' Patients with established primary care relationships they planned to continue,
#' significant dementia, specific plans to leave the Boston area that would
#' prevent research participation, failure to provide contact information for
#' tracking purposes, or pregnancy were excluded.
#' 
#' Subjects were interviewed at baseline during their detoxification
#' stay and follow-up interviews were undertaken every 6 months for 2
#' years.  A variety of continuous, count, discrete, and survival time
#' predictors and outcomes were collected at each of these five
#' occasions.
#' 
#' This dataset is a superset of the HELPrct data with 17 subjects with 
#' partially observed data on some of the baseline variables.  This is
#' a subset of the HELPfull data which includes 5 timepoints and many
#' additional variables.
#' 
#' @source 
#' \url{http://www.math.smith.edu/help}
#' 
#' @references 
#' Samet JH, Larson MJ, Horton NJ, Doyle K, Winter M, and Saitz R.  Linking alcohol and 
#' drug-dependent adults to primary medical care: 
#' A randomized controlled trial of 
#' a multi-disciplinary health intervention in a detoxification unit.  
#' \emph{Addiction}, 2003; 98(4):509-516.
#' 
#' @seealso \code{\link{HELPrct}} , and \code{\link{HELPfull}}.
#' 
#' 
#' @examples 
#' data(HELPmiss)
#' 
#' @keywords datasets

NA

#' Health Evaluation and Linkage to Primary Care
#' 
#' The HELP study was a clinical trial for adult inpatients recruited from a
#' detoxification unit.  Patients with no primary care physician were randomized
#' to receive a multidisciplinary assessment and a brief motivational intervention
#' or usual care, with the goal of linking them to primary medical care.
#' 
#' @name HELPrct
#' @usage data(HELPrct)
#' @docType data
#' @format 
#'   Data frame with 453 observations on the following variables.  
#'   
#'   \itemize{
#'     \item{\code{age}} {subject age at baseline (in years)}
#'     \item{\code{anysub}} {use of any substance post-detox: a factor with levels \code{no} \code{yes}} 
#'     \item{\code{cesd}} {Center for Epidemiologic Studies Depression measure at baseline (high scores indicate more depressive symptoms)}
#'     \item{\code{d1}} {lifetime number of hospitalizations for medical problems (measured at baseline)}
#'     \item{\code{daysanysub}} {time (in days) to first use of any substance post-detox}
#'     \item{\code{dayslink}} {time (in days) to linkage to primary care}
#'     \item{\code{drugrisk}} {Risk Assessment Battery drug risk scale at baseline}
#'     \item{\code{e2b}} {number of times in past 6 months entered a detox program (measured at baseline)}
#'     \item{\code{female}} {0 for male, 1 for female} 
#'     \item{\code{sex}} {a factor with levels \code{male} \code{female}} 
#'     \item{\code{g1b}} {experienced serious thoughts of suicide in last 30 days (measured at baseline): a factor with levels \code{no} \code{yes}}
#'     \item{\code{homeless}} {housing status: a factor with levels \code{housed} \code{homeless}}
#'     \item{\code{i1}} {average number of drinks (standard units) consumed per day, in the 
#' past 30 days (measured at baseline)}
#'     \item{\code{i2}} {maximum number of drinks (standard units) consumed per day, in the 
#' past 30 days (measured at baseline)}
#'     \item{\code{id}} {subject identifier}
#'     \item{\code{indtot}} {Inventory of Drug Use Consequences (InDUC) total score (measured at baseline)}
#'     \item{\code{linkstatus}} {post-detox linkage to primary care (0 = no, 1 = yes)}
#'     \item{\code{link}} {post-detox linkage to primary care: \code{no} \code{yes}} 
#'     \item{\code{mcs}} {SF-36 Mental Component Score (measured at baseline, lower scores indicate worse status)}
#'     \item{\code{pcs}} {SF-36 Physical Component Score (measured at baseline, lower scores indicate worse status)}
#'     \item{\code{pss_fr}} {perceived social support by friends (measured at baseline, higher scores indicate more support)}
#'     \item{\code{racegrp}} {race/ethnicity: levels \code{black} \code{hispanic} \code{other} \code{white}}
#'     \item{\code{satreat}} {any BSAS substance abuse treatment at baseline: \code{no} \code{yes}}
#'     \item{\code{sexrisk}} {Risk Assessment Battery sex risk score (measured at baseline)}
#'     \item{\code{substance}} {primary substance of abuse: \code{alcohol} \code{cocaine} \code{heroin}}
#'     \item{\code{treat}} {randomized to HELP clinic: \code{no} \code{yes}}
#'   }
#' 
#' 
#' @note
#' 	The \code{HELPrct} data set was originally named \code{HELP} but has 
#' 	been renamed to avoid confusion with the \code{help} function.
#' 
#' 
#' @details 
#' Eligible subjects were adults, who spoke Spanish or English, reported alcohol,
#' heroin or cocaine as their first or second drug of choice, resided in proximity
#' to the primary care clinic to which they would be referred or were homeless.
#' Patients with established primary care relationships they planned to continue,
#' significant dementia, specific plans to leave the Boston area that would
#' prevent research participation, failure to provide contact information for
#' tracking purposes, or pregnancy were excluded.
#' 
#' Subjects were interviewed at baseline during their detoxification
#' stay and follow-up interviews were undertaken every 6 months for 2
#' years.  A variety of continuous, count, discrete, and survival time
#' predictors and outcomes were collected at each of these five
#' occasions.
#' 
#' This dataset is a subset of the \code{\link{HELPmiss}}  data which includes an
#' additional 17 subjects with 
#' partially observed data on some of the baseline variables.  This is
#' also a subset of the \code{\link{HELPfull}}  data which includes 5 timepoints and many
#' additional variables for all subjects.
#' 
#' @source 
#' \url{http://www.math.smith.edu/help}
#' 
#' @references 
#' Samet JH, Larson MJ, Horton NJ, Doyle K, Winter M, and Saitz R.  Linking alcohol and 
#' drug-dependent adults to primary medical care: 
#' A randomized controlled trial of 
#' a multi-disciplinary health intervention in a detoxification unit.  
#' \emph{Addiction}, 2003; 98(4):509-516.
#' 
#' @seealso \code{\link{HELPmiss}}, and \code{\link{HELPfull}}.
#' 
#' 
#' @examples 
#' data(HELPrct)
#' 
#' @keywords datasets

NA

#' Foot measurements in children
#' 
#' These data were collected by a statistician, Mary C. Meyer, in a
#' fourth grade classroom in Ann Arbor, MI, in October 1997.  They are a
#' convenience sample --- the kids who were in the fourth grade.
#' 
#' @name KidsFeet
#' @usage data(KidsFeet)
#' @docType data
#' @format 
#'   A data frame with 39 observations on the following variables.
#'   \itemize{
#'     \item{\code{name}} {a factor with levels corresponding to the name of each child}
#'     \item{\code{birthmonth}} {the month of birth}
#'     \item{\code{birthyear}} {the year of birth}
#'     \item{\code{length}} {length of longer foot (in cm)}
#'     \item{\code{width}} {width of longer foot (in cm)}
#'     \item{\code{sex}} {a factor with levels \code{B} \code{G}}
#'     \item{\code{biggerfoot}} {a factor with levels \code{L} \code{R}}
#'     \item{\code{domhand}} {a factor with levels \code{L} \code{R}}
#'   }
#' 
#' @details 
#' Quoted from the source: ``From a very young age, shoes for boys tend to be wider than shoes for girls.  Is this because boys have wider feet, or because it is assumed that
#' girls, even in elementary school, are willing to sacrifice comfort for fashion?
#' To assess the former, a statistician measures kids' feet.''
#' 
#' @references 
#' Mary C. Meyer (2006) ``Wider Shoes for Wider Feet?''
#' \emph{Journal of Statistics Education} 14(1),
#' \url{www.amstat.org/publications/jse/v14n1/datasets.meyer.html}
#' 
#' @examples 
#' data(KidsFeet)
#' 
#' @keywords datasets

NA

#' Marriage records
#' 
#' Marriage records from the Mobile County, Alabama, probate court.  
#' 
#' @name Marriage
#' @usage data(Marriage)
#' @docType data
#' @format 
#'   A data frame with 98 observations on the following variables.
#'   \itemize{
#'     \item{\code{bookpageID}} {a factor with levels for each book and page (unique identifier)}
#'     \item{\code{appdate}} {a factor with levels corresponding to each of the dates on which the
#' application was filed (in the form MO/DY/YY, e.g. 1/22/99 represents January 22, 1999)}
#'     \item{\code{ceremonydate}} {a factor with levels corresponding to the date of the ceremony}
#'     \item{\code{delay}} {number of days between the application and the ceremony}
#'     \item{\code{officialTitle}} {a factor with levels \code{BISHOP} \code{CATHOLIC PRIEST} \code{CHIEF CLERK} \code{CIRCUIT JUDGE } \code{ELDER} \code{MARRIAGE OFFICIAL} \code{MINISTER} \code{PASTOR} \code{REVEREND}}
#'     \item{\code{person}} {a factor with levels \code{Bride} \code{Groom}}
#'     \item{\code{dob}} {a factor with levels corresponding to the date of birth of the person}
#'     \item{\code{age}} {age of the person (in years)}
#'     \item{\code{race}} {a factor with levels \code{American Indian} \code{Black} \code{Hispanic} \code{White}}
#'     \item{\code{prevcount}} {the number of previous marriages of the person, as listed on the
#' application}
#'     \item{\code{prevconc}} {the way the last marriage ended, as listed on the application}
#'     \item{\code{hs}} {the number of years of high school education, as listed on the application}
#'     \item{\code{college}} {the number of years College education, as listed on the application.  Where no number was listed, this field was left blank, unless less than 12 years High School was reported, in which case it was entered as 0.}
#'     \item{\code{dayOfBirth}} {the day of birth, as a number from 1 to 365 counting from January 1}
#'     \item{\code{sign}} {the astrological sign, with levels \code{Aquarius} \code{Aries} \code{Cancer} \code{Capricorn} \code{Gemini} \code{Leo} \code{Libra} \code{Pisces} \code{Saggitarius} \code{Scorpio} \code{Taurus} \code{Virgo}}
#'   }
#' 
#' @details 
#' The calculation of the astrological sign may not correctly sort people directly on the borders between signs.  This variable is not part of the original record.
#' 
#' @source 
#' The records were collected through 
#' \url{http://www.mobilecounty.org/probatecourt/recordssearch.htm}
#' 
#' @examples 
#' data(Marriage)
#' 
#' @keywords datasets

NA

#' Mites and Wilt Disease 
#'
#' Data from an experiment to test whether exposure to mites protects against Wilt Disease in
#' cotton plants.
#' 
#' @name Mites
#' @usage data(Mites)
#' @docType data
#' @format 
#'   A data frame with 47 observations on the following variables.
#'   \itemize{
#'     \item{\code{treatment}} {a factor with levels \code{mites} and \code{no mites}}
#'     \item{\code{outcome}} {a factor with levels \code{wilt} and \code{no wilt}}
#'     }
#'     
#' @details
#' Researchers suspected that attack of a plant by one organism induced resistance to subsequent attack by a different organism.  Individually potted cotton plants were randomly allocated to two groups: infestation by spider mites or no infestation.  After two weeks the mites were dutifully removed by a conscientious research assistant, and both groups were inoculated with Verticillium, a fungus that causes Wilt disease.  More information can be found at \url{https://www.causeweb.org/webinar/activity/2010-01/}.
#'
#' @source
#' Statistics for the Life Sciences, Third Edition; Myra Samuels & Jeffrey Witmer (2003), page 409.
#' 
#' @examples 
#' data(Mites)
#' if (require(mosaic)) {
#'   tally(~ treatment + outcome, data=Mites)
#'   tally(~ outcome | treatment, format="percent", data=Mites)
#' }
#' 
#' @keywords datasets

NA


#' State by State SAT data 
#' 
#' 
#' SAT data assembled for a statistics education journal article on the 
#' link between SAT scores and measures of educational expenditures
#' 
#' 
#' @name SAT
#' @usage data(SAT)
#' @docType data
#' @format 
#'   A data frame with 50 observations on the following variables.
#'   \itemize{
#'     \item{\code{state}} {a factor with names of each state}
#'     \item{\code{expend}} {expenditure per pupil in average daily attendance in
#'  public elementary and secondary schools, 1994-95 (in thousands of US dollars)}
#'     \item{\code{ratio}} {average pupil/teacher ratio in public elementary and secondary
#' schools, Fall 1994}
#'     \item{\code{salary}} {estimated average annual salary of teachers in public elementary
#' and secondary schools, 1994-95 (in thousands of US dollars)}
#'     \item{\code{frac}} {percentage of all eligible students taking the SAT, 1994-95}
#'     \item{\code{verbal}} {average verbal SAT score, 1994-95}
#'     \item{\code{math}} {average math SAT score, 1994-95}
#'     \item{\code{sat}} {average total SAT score, 1994-95}
#'   }
#' 
#' @source 
#' http://www.amstat.org/publications/jse/secure/v7n2/datasets.guber.cfm
#' 
#' @references 
#' Deborah Lynn Guber, "Getting what you pay for: the debate over equity in
#' public school expenditures" (1999), \emph{Journal of Statistics Education} 7(2).
#' 
#' @examples 
#' data(SAT)
#' if (require(lattice)) {
#'   xyplot(sat ~ expend, SAT)
#'   xyplot(sat ~ expend, SAT, 
#' 	   panel=function(x,y){grid.text(abbreviate(SAT$state, 3), x, y, default.units='native')})
#' } 
#' @keywords datasets

NA

#' Cherry Blossom Race
#' 
#' The Cherry Blossom 10 Mile Run is a road race held in Washington,
#' D.C. in April each year.  (The name comes from the famous cherry trees
#' that are in bloom in April in Washington.)  The results of this race
#' are published.  This data frame  contains the results from the 2005 race. 
#' 
#' @name TenMileRace
#' @usage data(TenMileRace)
#' @docType data
#' @format 
#'   A data frame with 8636 observations on the following variables.
#'   \itemize{
#'     \item{\code{state}} {State of residence of runner.}
#'     \item{\code{time}} {Official time from starting gun to finish line.}
#'     \item{\code{net}} {The recorded time (in seconds) from when the runner crossed the starting
#' line to when the runner crossed the finish line.  This is generally
#' less than the official time because of the large number of runners in
#' the race: it takes time to reach the starting line after the gun has
#' gone off.}
#'     \item{\code{age}} {Age of runner in years.}
#'     \item{\code{sex}} {A factor with levels \code{F} \code{M}.}
#'   }
#' 
#' @examples 
#' data(TenMileRace)
#' if (require(lattice)) {
#'   xyplot(net ~ age, data=TenMileRace, groups=sex)
#'   lm(net ~ age + sex, data=TenMileRace)
#' }
#' 
#' @keywords datasets

NA

#' Utility bills 
#' 
#' Data from utility bills at a residence.
#' \code{\link{Utilities2}}  is a similar data set with some additional variables.
#' 
#' @name Utilities
#' @usage data(Utilities)
#' @docType data
#' @format 
#'   A data frame containing 117 observations for the following variables.
#'   \itemize{
#'     \item{\code{month}} {month (coded as a number)}
#'     \item{\code{day}} {day of month on which bill was calculated}
#'     \item{\code{year}} {year of bill}
#'     \item{\code{temp}} {average temperature (F) for billing period}
#'     \item{\code{kwh}} {electricity usage (kwh)}
#'     \item{\code{ccf}} {gas usage (ccf)}
#'     \item{\code{thermsPerDay}} {a numeric vector}
#'     \item{\code{billingDays}} {number of billing days in billing period}
#'     \item{\code{totalbill}} {total bill (in dollars)}
#'     \item{\code{gasbill}} {gas bill (in dollars)}
#'     \item{\code{elecbill}} {exectric bill (in dollars)}
#'     \item{\code{notes}} {notes about the billing period}
#'   }
#' 
#' @source 
#' Daniel T. Kaplan, \emph{Statistical modeling: A fresh approach}, 2009. 
#' 
#' @examples 
#' data(Utilities)
#' if (require(lattice)) {
#'   xyplot(gasbill ~ temp, Utilities)
#' }
#' 
#' @seealso \code{\link{Utilities2}}.
#' @keywords datasets

NA

#' Utility bills 
#' 
#' Data from utility bills at a private residence.  This is an augmented version 
#' of \code{\link{Utilities}}.
#' 
#' @name Utilities2
#' @usage data(Utilities2)
#' @docType data
#' @format 
#'   A data frame containing 117 observations for the following variables.
#'   \itemize{
#'     \item{\code{month}} {month (coded as a number)}
#'     \item{\code{day}} {day of month on which bill was calculated}
#'     \item{\code{year}} {year of bill}
#'     \item{\code{temp}} {average temperature (F) for billing period}
#'     \item{\code{kwh}} {electricity usage (kwh)}
#'     \item{\code{ccf}} {gas usage (ccf)}
#'     \item{\code{thermsPerDay}} {a numeric vector}
#'     \item{\code{billingDays}} {number of billing days in billing period}
#'     \item{\code{totalbill}} {total bill (in dollars)}
#'     \item{\code{gasbill}} {gas bill (in dollars)}
#'     \item{\code{elecbill}} {exectric bill (in dollars)}
#'     \item{\code{notes}} {notes about the billing period}
#'     \item{\code{ccfpday}} {average gas usage per day [\code{Utilities2} only]}
#'     \item{\code{kwhpday}} {average electric usage per day [\code{Utilities2} only]}
#'     \item{\code{gasbillpday}} {gas bill divided by billing days [\code{Utilities2} only]}
#'     \item{\code{elecbillpday}} {electric bill divided by billing days a numeric vector [\code{Utilities2} only]}
#'     \item{\code{totalbillpday}} {total bill divided by billing days a numeric vector [\code{Utilities2} only]}
#'     \item{\code{therms}} {\code{thermsPerDay * billingDays} [\code{Utilities2} only]}
#'     \item{\code{monthsSinceY2K}} {months since 2000 [\code{Utilities2} only]}
#'   }
#' 
#' @source 
#' Daniel T. Kaplan, \emph{Statistical modeling: A fresh approach}, 2009. 
#' 
#' @examples 
#' data(Utilities2)
#' if (require(lattice)) {
#'   xyplot(gasbillpday ~ temp, Utilities2)
#' }
#' 
#' @seealso \code{\link{Utilities}}.
#' @keywords datasets

NA

#' Data from the Whickham survey
#' 
#' Data on age, smoking, and mortality
#' from a one-in-six survey of the electoral roll
#' in Whickham, a mixed urban and rural district near Newcastle upon
#' Tyne, in the UK. The survey was conducted in 1972-1974 to study
#' heart disease and thyroid disease.  A follow-up on those in the
#' survey was conducted twenty years later.
#' 
#' @name Whickham
#' @usage data(Whickham)
#' @docType data
#' @format 
#'   A data frame with 1314 observations on women for the following  variables.
#'   \itemize{
#'     \item{\code{outcome}} {survival status after 20 years: a factor with levels \code{Alive} \code{Dead}}
#'     \item{\code{smoker}} {smoking status at baseline: a factor with levels \code{No} \code{Yes}}
#'     \item{\code{age}} {age (in years) at the time of the first survey}
#'   }
#' 
#' @details 
#' This dataset contains a
#' subset of the survey sample: women who were classified as current
#' smokers or as never having smoked.
#' The data were 
#' synthesized from the summary description tables given
#' in the Appleton et al al paper.
#' 
#' @references 
#' DR Appleton, JM French, MPJ Vanderpump.  "Ignoring a covariate: an example
#' of Simpson's paradox". (1996)
#' \emph{American Statistician}, 50(4):340-341. 
#' 
#' @examples 
#' data(Whickham)
#' 
#' @keywords datasets

NA

#' Snowfall data for Grand Rapids, MI
#' 
#' Official snowfall data by month and season for Grand Rapids, MI, going back to 1893.
#' 
#' @name SnowGR
#' @usage data(SnowGR)
#' @docType data
#' @format 
#'   A data frame with 119 observations of the following variables.
#'   \itemize{
#'       \item \code{SeasonStart} Year in which season started (July is start of season)
#'       \item \code{SeasonEnd} Year in which season ended (June is end of season)
#'       \item \code{Jul} Inches of snow in July
#'       \item \code{Aug} Inches of snow in August
#'       \item \code{Sep} Inches of snow in September
#'       \item \code{Oct} Inches of snow in October
#'       \item \code{Nov} Inches of snow in November
#'       \item \code{Dec} Inches of snow in December
#'       \item \code{Jan} Inches of snow in January
#'       \item \code{Feb} Inches of snow in February
#'       \item \code{Mar} Inches of snow in March
#'       \item \code{Apr} Inches of snow in April
#'       \item \code{May} Inches of snow in May
#'       \item \code{Jun} Inches of snow in June
#'       \item \code{Total} Inches of snow for entire season (July-June)
#'   }
#' 
#' @source
#'    These data were compiled by Laura Kapitula from data available at
#'     \url{http://www.crh.noaa.gov/grr/climate/data/grr/snowfall/}.
#' 
#' @examples 
#' data(SnowGR)
#' if (require(mosaic)) {
#'   favstats(SnowGR$Total)
#'   histogram(~Total, data=SnowGR)
#'   xyplot(Total ~ SeasonStart, SnowGR, type=c('p','smooth'))
#' }
#' if (require(reshape2)) {
#'   Snow2 <- melt(SnowGR, id=1:2)
#'   names(Snow2)[3:4] <- c('Time','Snow')
#'   bwplot(Snow ~ Time, Snow2)
#' }
#' 
#' @keywords datasets

NA

#' 100 m Swimming World Records
#' 
#' World records for men and women over time from 1905 through 2004.
#' 
#' @name SwimRecords
#' @usage data(SwimRecords)
#' @docType data
#' @format 
#'   A data frame with 62 observations of the following variables.
#'   \itemize{
#'       \item \code{time} time (in seconds) of the world record
#'       \item \code{year} Year in which the record was set
#'       \item \code{sex} a factor with levels \code{M} and \code{F}
#'   }
#' 
#' @examples 
#' data(SwimRecords)
#' if (require(lattice)) {
#'   xyplot(time~year, data=SwimRecords, groups=sex)
#' }
#' 
#' @keywords datasets

NA

#' CoolingWater
#' 
#' Temperature of a mug of water as it cools
#'  
#' @name CoolingWater
#' @usage data(CoolingWater)
#' @docType data
#' @format 
#'   A data frame with 222 observations of the following variables.
#'   \itemize{
#'       \item \code{time} time in minutes
#'       \item \code{temp} temperature in Celsius
#'   }
#' @source
#' These data were collected Stan Wagon to help his
#' mathematical modeling students explore Newton's 
#' Law of Cooling and the ways that the law is really 
#' only an approximation. More about Stan: \url{http://stanwagon.com}.
#' @details
#' The water was poured into a mug and a temperature probe inserted into
#' the water with a few seconds of the pour.
#' @examples 
#' data(CoolingWater)
#' if (require(lattice)) {
#'   xyplot(temp~time, data=CoolingWater)
#' }
#' 
#' @keywords datasets
NA

#' Height and Weight
#' 
#' The height and weight data collected from 57 males and 24 females for the
#' purpose of exploring how the weight of a person is related to his or her height.
#'  
#'  @docType data
#'  @name Heightweight
#'  @usage data(Heightweight)
#'  @format
#'      A data frame with 81 observations on the following variables.
#'   
#'  \itemize{
#'    \item{\code{female}} {0 = male, 1 = female}
#'    \item{\code{gender}} {a factor with levels \code{male} or \code{female}}
#'    \item{\code{height}} {subject height (in inches)}
#'    \item{\code{weight}} {subject weight (in pounds)}
#'  }
#' 
#' @references
#' Part of the Carnegie Mellon University Online Learning Initiative datasets.
#' 
#' @keywords datasets

NA

